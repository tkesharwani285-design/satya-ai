// Offline demo scenarios (the "Try a demo" chips). These never touch the backend.
// They are written in the original compact format and converted to the same view model as live results.

const RAW = [
  { id: "flood", tone: "high", chip: "Recycled 2018 Flood Photo", mode: "image", input: "viral_flood_photo.jpg",
    score: 88, verdictText: "High Misinformation Risk",
    summary: "This image circulating as 'floods in the city this week' first appeared online in August 2018 and shows a different region. Its caption uses alarmist language and is being pushed by a coordinated cluster of new accounts.",
    temporal: { claimed: "This week", original: "14 Aug 2018", gap: "8 years 2 months", note: "Earliest indexed upload found on a regional news archive; EXIF metadata stripped.", hits: [["Regional daily archive", "14 Aug 2018", "Original caption: coastal district flooding"], ["Photo-sharing site", "15 Aug 2018", "Same frame, higher resolution"], ["Social repost (viral)", "This week", "Caption altered to claim current event"]] },
    ling: { sens: 91, emo: 84, lines: [["BREAKING!!! City is DROWNING, officials are HIDING the truth", 95], ["Share before it gets deleted — thousands trapped", 88], ["Photo taken by a resident near the old market", 40], ["Water levels rose within hours", 22]], flags: ["Urgency trigger", "Conspiracy framing", "Unverifiable eyewitness"] },
    bot: { pct: 73, accounts: 412, age: "81% under 30 days old", note: "Posting bursts every 4–6 minutes with near-identical captions and hashtag sets.", series: [8, 12, 20, 55, 90, 74, 60, 38, 24, 14] },
    audio: { na: true },
    checks: [["Reuters Fact Check", "False", "Image predates the claimed event by years.", "high"], ["AP News Verify", "Misleading", "Photo reused from a 2018 flood; location mismatch.", "high"], ["Google Fact Check index", "3 matching reviews", "Rated False by independent reviewers.", "high"]] },
  { id: "bank", tone: "verified", chip: "Central Bank Policy", mode: "text", input: "Central bank holds the repo rate steady at its latest monetary policy meeting, citing easing inflation.",
    score: 6, verdictText: "Verified – Low Risk",
    summary: "The claim matches the official policy statement and is reported consistently by multiple independent outlets. Language is neutral and no coordinated amplification was detected.",
    temporal: { claimed: "Today", original: "Today", gap: "No mismatch", note: "Primary source published the same day; timeline is consistent.", hits: [["Official policy statement", "Today", "Primary source"], ["Wire report", "Today", "Same figures, attributed"], ["Business daily", "Today", "Analysis with quotes"]] },
    ling: { sens: 8, emo: 5, lines: [["Central bank keeps repo rate unchanged", 6], ["Governor cites easing inflation and stable growth", 10], ["Markets reacted calmly to the announcement", 12]], flags: ["Neutral tone", "Attributed sources"] },
    bot: { pct: 4, accounts: 9, age: "Organic account mix", note: "Spread follows normal news-cycle patterns with no synthetic bursts.", series: [30, 44, 40, 34, 28, 22, 18, 14, 10, 8] },
    audio: { na: true },
    checks: [["Reuters", "Confirmed", "Matches reported decision and rationale.", "verified"], ["AP News", "Confirmed", "Consistent with the official statement.", "verified"], ["Google Fact Check index", "No disputes", "No fact-checks flag this claim.", "verified"]] },
  { id: "voice", tone: "caution", chip: "Cloned Leader Voice Note", mode: "audio", input: "forwarded_voice_note.ogg",
    score: 64, verdictText: "Caution – Likely Synthetic Audio",
    summary: "The voice note shows spectral artifacts typical of text-to-speech cloning and an unnaturally even pitch. No credible outlet has reported the statement attributed to the speaker.",
    temporal: { claimed: "Yesterday", original: "First seen yesterday", gap: "No earlier source", note: "No original broadcast or recording found for this statement.", hits: [["Messaging forward chain", "Yesterday", "Earliest known share"], ["Public speech archive", "—", "No matching speech"]] },
    ling: { sens: 58, emo: 71, lines: [["I am telling you all to stop what you are doing now", 74], ["The government will not tell you this", 80], ["Please forward to everyone you know", 66]], flags: ["Chain-forward request", "Appeal to secrecy"] },
    bot: { pct: 38, accounts: 126, age: "44% under 90 days old", note: "Moderate automated forwarding across group chats.", series: [4, 10, 22, 36, 40, 33, 25, 18, 12, 9] },
    audio: { synth: 79, cloneProb: "High", notes: ["Missing breath sounds between phrases", "Flat micro-pitch variation (±0.4 Hz)", "Spectral cutoff above 8 kHz typical of neural TTS", "Background noise loop repeats every 3.2 s"], bars: [20, 34, 48, 62, 70, 64, 58, 72, 80, 76, 60, 44, 30, 22] },
    checks: [["Reuters Fact Check", "No record", "No reporting on the claimed statement.", "caution"], ["AP News Verify", "Under review", "Audio authenticity flagged for review.", "caution"], ["Google Fact Check index", "1 related review", "Similar cloned-audio forwards rated Misleading.", "caution"]] },
];

const levelTone = (v) => (v >= 60 ? 'high' : v >= 30 ? 'caution' : 'verified');

function toViewModel(s) {
  return {
    source: 'demo',
    id: s.id,
    mode: s.mode,
    input: s.input,
    tone: s.tone,
    score: s.score,
    trust: 100 - s.score,
    verdictText: s.verdictText,
    summary: s.summary,
    temporal: {
      stats: [
        { label: 'Claimed date', value: s.temporal.claimed },
        { label: 'Original upload', value: s.temporal.original, tone: s.tone === 'high' ? 'high' : undefined },
        { label: 'Time gap', value: s.temporal.gap, sub: s.temporal.note },
      ],
      hitsTitle: 'Reverse-search timeline',
      hits: s.temporal.hits.map(([title, date, note]) => ({ title, date, note })),
      signals: [],
      exif: [],
    },
    ling: {
      sens: s.ling.sens,
      emo: s.ling.emo,
      lines: s.ling.lines.map(([text, score]) => ({ text, score })),
      flags: s.ling.flags,
      phrases: [],
    },
    bot: {
      stats: [
        { label: 'Synthetic amplification', value: s.bot.pct + '%', tone: levelTone(s.bot.pct) },
        { label: 'Suspect accounts', value: s.bot.accounts },
        { label: 'Account age', value: s.bot.age },
      ],
      series: s.bot.series,
      seriesLabel: 'Shares per hour',
      note: s.bot.note,
    },
    audio: s.audio.na
      ? null
      : {
          stats: [
            { label: 'Synthetic speech score', value: s.audio.synth + '%', tone: 'caution' },
            { label: 'Voice-clone probability', value: s.audio.cloneProb, tone: 'caution' },
          ],
          signals: s.audio.notes.map((n) => ({ name: n, value: '', flagged: true, note: '' })),
          bars: s.audio.bars,
        },
    checks: s.checks.map(([src, verdict, note, tone]) => ({ src, verdict, note, tone })),
    coverage: null,
    claims: [],
  };
}

export const DEMOS = RAW.map(toViewModel);
export const DEMO_CHIPS = RAW.map((s) => ({ id: s.id, tone: s.tone, chip: s.chip }));
