import { useEffect, useRef, useState } from 'react';
import Icon from './Icon.jsx';
import { Modal, Spinner } from './Modal.jsx';

const mkQ = () => ({ a: 2 + Math.floor(Math.random() * 8), b: 2 + Math.floor(Math.random() * 8) });

export default function CaptchaModal({ onClose, onDone }) {
  const [mode, setMode] = useState("box");
  const [st, setSt] = useState("idle");
  const [q, setQ] = useState(mkQ);
  const [ans, setAns] = useState("");
  const [err, setErr] = useState(false);
  const t = useRef();
  useEffect(() => () => clearTimeout(t.current), []);
  const ok = () => { setSt("ok"); t.current = setTimeout(onDone, 1000); };
  const clickBox = () => { if (st !== "idle") return; setSt("loading"); t.current = setTimeout(ok, 1300); };
  const math = (e) => { e.preventDefault(); if (st === "ok") return; if (parseInt(ans, 10) === q.a + q.b) ok(); else { setErr(true); setAns(""); setQ(mkQ()); } };
  return (
    <Modal title="Security Verification — Are You Human?" onClose={onClose}>
      {st === "ok" ? (
        <div className="text-center py-6 rise">
          <span className="mx-auto grid place-items-center w-16 h-16 rounded-full bg-emerald-500/15 border border-emerald-400/50 text-emerald-300 shadow-[0_0_36px_rgba(16,185,129,.5)]"><Icon n="check" s={30} /></span>
          <p className="mt-4 text-emerald-300 font-semibold text-lg">Human Verified</p>
          <p className="text-sm text-slate-400 mt-1">Starting analysis…</p>
        </div>
      ) : (
        <>
          <p className="text-sm text-slate-400 mb-4">Satya checks every request to keep bots from flooding the engine. This takes a few seconds.</p>
          <div role="tablist" className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-950/60 border border-slate-800 mb-4">
            {[["box", "Quick check"], ["math", "Math challenge"]].map(([id, l]) => <button key={id} role="tab" aria-selected={mode === id} disabled={st === "loading"} onClick={() => setMode(id)} className={"py-2 rounded-lg text-sm transition-colors " + (mode === id ? "bg-indigo-500/25 text-cyan-300" : "text-slate-400 hover:text-white")}>{l}</button>)}
          </div>
          {mode === "box" ? (
            <button onClick={clickBox} className="w-full flex items-center gap-4 rounded-xl border border-slate-700 bg-slate-950/70 hover:border-cyan-400/50 px-4 py-4 text-left transition-colors">
              <span className="grid place-items-center w-7 h-7 rounded-md border-2 border-slate-600">{st === "loading" && <Spinner c="w-5 h-5" />}</span>
              <span className="flex-1 text-slate-100">{st === "loading" ? "Verifying…" : "I am human"}</span>
              <span className="text-right text-xs text-slate-500 leading-tight"><Icon n="shield" s={16} c="ml-auto text-cyan-400" />Satya Shield</span>
            </button>
          ) : (
            <form onSubmit={math} className="space-y-3">
              <label className="block text-slate-100">What is <b className="text-cyan-300 text-lg">{q.a} + {q.b}</b> ?
                <input autoFocus inputMode="numeric" value={ans} onChange={(e) => { setAns(e.target.value); setErr(false); }} placeholder="Your answer" className="mt-2 w-full bg-slate-950/70 border border-slate-800 focus:border-cyan-400/60 outline-none rounded-xl px-4 py-2.5 text-slate-100 placeholder-slate-500" />
              </label>
              {err && <p role="alert" className="text-sm text-rose-300">That wasn’t right. Try this new question.</p>}
              <button type="submit" disabled={!ans.trim()} className="w-full py-2.5 rounded-xl font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-40 shadow-[0_0_24px_rgba(34,211,238,.45)] transition-all">Check answer</button>
            </form>
          )}
        </>
      )}
    </Modal>
  );
}
