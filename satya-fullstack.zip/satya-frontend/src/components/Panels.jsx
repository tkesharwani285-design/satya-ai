import { Fragment } from 'react';
import Icon from './Icon.jsx';
import { TONE, Stat, heat, barTone } from './ui.jsx';

const Empty = ({ icon = "alert", children }) => (
  <div className="rise text-center py-10 text-slate-400 max-w-lg mx-auto"><Icon n={icon} s={28} c="mx-auto mb-3 text-slate-600" />{children}</div>
);

const Bar = ({ label, v, good }) => (
  <div className="rounded-xl bg-slate-950/60 border border-slate-800 p-4">
    <div className="flex justify-between text-sm"><span className="text-slate-300">{label}</span><span className="text-white font-semibold">{v}/100</span></div>
    <div className="h-2 rounded bg-slate-800 mt-2 overflow-hidden"><div className={"h-full rounded " + (good ? (v > 60 ? "bg-emerald-500" : v > 35 ? "bg-amber-500" : "bg-rose-500") : barTone(v))} style={{ width: v + "%" }} /></div>
  </div>
);

const Link = ({ href, children, className = "" }) => href
  ? <a href={href} target="_blank" rel="noopener noreferrer" className={"hover:text-cyan-300 hover:underline " + className}>{children}</a>
  : <span className={className}>{children}</span>;

function Temporal({ r }) {
  const t = r.temporal;
  if (!t) return <Empty icon="clock">Temporal audit applies to images (reverse-image search and original upload date) and articles (publish date). Verify an image or a URL to use it.</Empty>;
  return (
    <div className="rise space-y-4">
      <div className="grid sm:grid-cols-3 gap-3">{t.stats.map((s) => <Stat key={s.label} {...s} />)}</div>
      <div className="space-y-2">
        <h4 className="text-sm text-slate-400">{t.hitsTitle}</h4>
        {t.hits.length === 0 && <p className="text-sm text-slate-500 rounded-xl bg-slate-950/60 border border-slate-800 p-3">{t.hitsEmpty || "Nothing to show."}</p>}
        {t.hits.map((h, i) => (
          <div key={i} className="flex items-start gap-3 rounded-xl bg-slate-950/60 border border-slate-800 p-3">
            <span className="mt-1 w-2.5 h-2.5 rounded-full bg-cyan-400 shrink-0 shadow-[0_0_10px_#22d3ee]" />
            <div className="flex-1 min-w-0"><Link href={h.url} className="text-slate-100 text-sm font-medium break-words">{h.title}</Link><div className="text-xs text-slate-500 break-words">{h.note}</div></div>
            <span className="text-xs text-slate-300 whitespace-nowrap">{h.date}</span>
          </div>))}
      </div>
      {t.manip != null && (
        <div className="space-y-2">
          <div className="flex justify-between text-sm"><h4 className="text-slate-400">Manipulation indicators</h4><span className="text-slate-300">{t.manip}/100</span></div>
          {t.signals.length ? <ul className="space-y-2">{t.signals.map((s) => <li key={s} className="flex gap-2 text-sm text-slate-300"><Icon n="alert" s={16} c="text-amber-400 mt-0.5 shrink-0" />{s}</li>)}</ul>
            : <p className="text-sm text-slate-500">No manipulation signals detected.</p>}
        </div>)}
      {t.exifPresent === false && <p className="text-xs text-slate-500">No EXIF metadata found. Social platforms usually strip it, so this alone is not suspicious.</p>}
      {t.exif.length > 0 && (
        <details className="rounded-xl bg-slate-950/60 border border-slate-800 p-3 text-sm">
          <summary className="cursor-pointer text-slate-300">EXIF metadata ({t.exif.length})</summary>
          <dl className="mt-3 grid grid-cols-[max-content_1fr] gap-x-4 gap-y-1">{t.exif.map(([k, v]) => <Fragment key={k}><dt className="text-slate-500">{k}</dt><dd className="text-slate-300 break-all">{v}</dd></Fragment>)}</dl>
        </details>)}
    </div>
  );
}

function Linguistic({ r }) {
  const l = r.ling;
  if (!l) return <Empty icon="lang">Linguistic analysis needs text. Verify an article, a claim, or a voice note with a transcript.</Empty>;
  return (
    <div className="rise space-y-4">
      <div className="grid sm:grid-cols-2 gap-3">
        <Bar label="Sensationalism" v={l.sens} />
        <Bar label="Emotional manipulation" v={l.emo} />
        {l.click != null && <Bar label="Clickbait" v={l.click} />}
        {l.neutral != null && <Bar label="Neutrality" v={l.neutral} good />}
      </div>
      {l.lines.length > 0 && <>
        <h4 className="text-sm text-slate-400">Emotional heatmap</h4>
        <div className="space-y-2">{l.lines.slice(0, 20).map((s, i) => <div key={i} className={"rounded-lg border px-3 py-2 text-sm text-slate-100 flex justify-between gap-3 " + heat(s.score)}><span className="break-words min-w-0">{s.text}</span><span className="text-xs text-slate-400 shrink-0">{s.score}</span></div>)}</div>
      </>}
      {l.flags.length > 0 && <div className="flex flex-wrap gap-2">{l.flags.map((f) => <span key={f} className="text-xs px-2.5 py-1 rounded-full bg-indigo-500/15 border border-indigo-400/30 text-indigo-200">{f}</span>)}</div>}
      {l.phrases.length > 0 && <div><h4 className="text-sm text-slate-400 mb-2">Flagged phrases</h4><div className="flex flex-wrap gap-2">{l.phrases.map((p) => <span key={p} className="text-xs px-2.5 py-1 rounded-full bg-rose-500/10 border border-rose-500/30 text-rose-200">“{p}”</span>)}</div></div>}
    </div>
  );
}

function Bot({ r }) {
  const b = r.bot;
  if (!b || b.unavailable) return <Empty icon="bot">{b?.unavailable || "Bot-swarm analysis is not available for this item."}</Empty>;
  const max = Math.max(...b.series, 1);
  return (
    <div className="rise space-y-4">
      {b.simulated && <p className="text-xs px-3 py-2 rounded-lg border border-amber-500/40 bg-amber-500/10 text-amber-200">Simulated demo data: no social-data provider is configured on the server.</p>}
      <div className="grid sm:grid-cols-3 gap-3">{b.stats.map((s) => <Stat key={s.label} {...s} />)}</div>
      {b.series.length > 0 && (
        <div className="rounded-xl bg-slate-950/60 border border-slate-800 p-4">
          <div className="text-sm text-slate-400 mb-3">{b.seriesLabel}</div>
          <div className="flex items-end gap-2 h-28">{b.series.map((v, i) => <div key={i} className="flex-1 rounded-t bg-gradient-to-t from-indigo-500 to-cyan-400" style={{ height: Math.max((v / max) * 100, 4) + "%" }} title={String(v)} />)}</div>
          <p className="text-sm text-slate-400 mt-3">{b.note}</p>
        </div>)}
    </div>
  );
}

function Audio({ r }) {
  const a = r.audio;
  if (!a) return <Empty icon="mic">No audio attached to this item. Upload a voice note in the <b className="text-cyan-300">Audio / Voice Note</b> tab, or try the <b className="text-cyan-300">Cloned Leader Voice Note</b> demo.</Empty>;
  const tr = a.transcript;
  return (
    <div className="rise space-y-4">
      <div className="grid sm:grid-cols-3 gap-3">{a.stats.map((s) => <Stat key={s.label} {...s} />)}</div>
      {a.bars && (
        <div className="rounded-xl bg-slate-950/60 border border-slate-800 p-4">
          <div className="text-sm text-slate-400 mb-3">Spectrogram (energy by band)</div>
          <div className="grid gap-1" style={{ gridTemplateColumns: "repeat(14,1fr)" }}>
            {Array.from({ length: 6 }).map((_, row) => a.bars.map((b, c) => { const lvl = b - row * 14; return <div key={row + "-" + c} className="h-4 rounded-sm" style={{ background: `rgba(${lvl > 40 ? "34,211,238" : "129,140,248"},${Math.max(0.08, Math.min(1, lvl / 80))})` }} />; }))}
          </div>
        </div>)}
      <ul className="space-y-2">
        {a.signals.map((s) => (
          <li key={s.name} className="flex gap-2 text-sm text-slate-300">
            <Icon n={s.flagged ? "alert" : "check"} s={16} c={(s.flagged ? "text-amber-400" : "text-emerald-400") + " mt-0.5 shrink-0"} />
            <span className="min-w-0 break-words"><span className="text-slate-100">{s.name}</span>{s.value ? <span className="text-slate-400"> · {s.value}</span> : null}{s.note ? <span className="block text-xs text-slate-500">{s.note}</span> : null}</span>
          </li>))}
      </ul>
      {tr && (
        <div className="rounded-xl bg-slate-950/60 border border-slate-800 p-4">
          <div className="flex flex-wrap justify-between gap-2 text-sm text-slate-400 mb-2"><span>Transcript</span><span className="text-xs text-slate-500">{[tr.provider, tr.lang].filter(Boolean).join(" · ")}</span></div>
          {tr.status === "ok" && tr.text ? <>
            <p className="text-slate-200 text-sm leading-relaxed break-words">{tr.text}</p>
            {tr.english && tr.english !== tr.text && <p className="mt-3 text-sm text-slate-400 break-words"><span className="text-xs text-slate-500 block mb-0.5">English translation (used for fact-checking)</span>{tr.english}</p>}
          </> : <p className="text-sm text-slate-500">{tr.status === "unavailable" ? "No transcription provider is configured on the server (set SARVAM_API_KEY or OPENAI_API_KEY), so the spoken claim was not fact-checked." : "Transcription failed, so the spoken claim was not fact-checked."}</p>}
        </div>)}
    </div>
  );
}

function Checks({ r }) {
  return (
    <div className="rise space-y-3">
      {r.coverage === "unavailable" && <p className="text-xs px-3 py-2 rounded-lg border border-amber-500/40 bg-amber-500/10 text-amber-200">Fact-check providers are not configured on the server (GOOGLE_FACTCHECK_API_KEY / TAVILY_API_KEY), so these results are limited.</p>}
      {r.coverage === "none" && r.checks.length === 0 && <p className="text-sm text-slate-400">No fact-checkers have reviewed this claim yet.</p>}
      {r.checks.length === 0 && !r.coverage && <Empty icon="shield">Source cross-referencing runs on claim text. Verify an article, a claim, or a voice note with a transcript.</Empty>}
      {r.checks.map((c, i) => (
        <div key={c.src + i} className="flex items-start gap-3 rounded-xl bg-slate-950/60 border border-slate-800 p-4">
          <Icon n="ext" c="text-slate-500 mt-1 shrink-0" />
          <div className="flex-1 min-w-0"><Link href={c.url} className="text-slate-100 font-medium break-words">{c.src}</Link><div className="text-sm text-slate-400 break-words">{c.note}</div></div>
          <span className={"text-xs px-2.5 py-1 rounded-full border whitespace-nowrap " + TONE[c.tone].chip}>{c.verdict}</span>
        </div>))}
      {r.claims.length > 0 && <>
        <h4 className="text-sm text-slate-400 pt-2">Claims checked</h4>
        {r.claims.map((c, i) => (
          <div key={i} className="flex items-start gap-3 rounded-xl bg-slate-950/60 border border-slate-800 p-4">
            <div className="flex-1 min-w-0"><div className="text-slate-100 text-sm break-words">{c.claim}</div>{c.entities.length > 0 && <div className="text-xs text-slate-500 mt-1">{c.entities.join(" · ")}</div>}</div>
            <span className={"text-xs px-2.5 py-1 rounded-full border whitespace-nowrap " + TONE[c.tone].chip}>{c.consensus}</span>
          </div>))}
      </>}
    </div>
  );
}

export default function Panel({ r, tab }) {
  if (tab === "temporal") return <Temporal r={r} />;
  if (tab === "ling") return <Linguistic r={r} />;
  if (tab === "bot") return <Bot r={r} />;
  if (tab === "audio") return <Audio r={r} />;
  return <Checks r={r} />;
}
