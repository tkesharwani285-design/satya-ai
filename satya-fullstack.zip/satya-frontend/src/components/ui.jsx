export const TONE = {
  high: { label: "High Risk", chip: "bg-rose-500/15 text-rose-300 border-rose-500/40", text: "text-rose-400", bar: "bg-rose-500", glow: "shadow-[0_0_40px_-8px_rgba(244,63,94,.55)]" },
  caution: { label: "Caution", chip: "bg-amber-500/15 text-amber-300 border-amber-500/40", text: "text-amber-400", bar: "bg-amber-500", glow: "shadow-[0_0_40px_-8px_rgba(245,158,11,.5)]" },
  verified: { label: "Verified", chip: "bg-emerald-500/15 text-emerald-300 border-emerald-500/40", text: "text-emerald-400", bar: "bg-emerald-500", glow: "shadow-[0_0_40px_-8px_rgba(16,185,129,.5)]" },
  neutral: { label: "Unknown", chip: "bg-slate-500/15 text-slate-300 border-slate-500/40", text: "text-slate-300", bar: "bg-slate-500", glow: "" },
};

export const Stat = ({ label, value, sub, tone }) => (
  <div className="rounded-xl bg-slate-950/60 border border-slate-800 p-4">
    <div className="text-xs text-slate-500">{label}</div>
    <div className={"text-xl font-bold mt-1 break-words " + (tone && TONE[tone] ? TONE[tone].text : "text-white")}>{value}</div>
    {sub && <div className="text-xs text-slate-500 mt-1">{sub}</div>}
  </div>
);

export const heat = (v) => v > 70 ? "bg-rose-500/25 border-rose-500/50" : v > 40 ? "bg-amber-500/20 border-amber-500/40" : "bg-emerald-500/10 border-emerald-500/30";
export const barTone = (v) => v > 70 ? "bg-rose-500" : v > 40 ? "bg-amber-500" : "bg-emerald-500";
