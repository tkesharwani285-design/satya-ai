import Icon from './Icon.jsx';
import Panel from './Panels.jsx';
import { TONE } from './ui.jsx';

const RT = [["temporal", "Temporal Audit", "clock"], ["ling", "Linguistic", "lang"], ["bot", "Bot Swarm", "bot"], ["audio", "Audio", "wave"], ["checks", "Fact-Check Sources", "shield"]];

export default function Results({ r, tab, setTab, human }) {
  const t = TONE[r.tone];
  return (
    <div id="results" className="rise space-y-5">
      <div className={"glass rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row gap-5 items-start " + t.glow}>
        <div className="flex sm:flex-col items-center gap-3 sm:w-44 shrink-0">
          <div className={"text-5xl font-extrabold " + t.text}>{r.score}%</div>
          <div className="sm:text-center"><span className={"inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full border font-semibold " + t.chip}><Icon n={r.tone === "verified" ? "shield" : "alert"} s={14} />{r.verdictText}</span><div className="text-xs text-slate-500 mt-1.5">Satya trust score: {r.trust}/100</div></div>
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-1.5">
            <span>Analyzed: <span className="text-slate-300 break-all">{r.input}</span></span>
            {r.source === "demo" && <span className="px-2 py-0.5 rounded-full border border-slate-600 bg-slate-800/60 text-slate-300">Demo data</span>}
            {human && <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border border-emerald-500/40 bg-emerald-500/10 text-emerald-300"><Icon n="check" s={12} />Human Verified</span>}
          </div>
          <h3 className="text-white font-semibold text-lg">Executive summary</h3>
          <p className="text-slate-300 mt-1.5 leading-relaxed">{r.summary}</p>
          <div className="h-1.5 rounded bg-slate-800 mt-4 overflow-hidden"><div className={"h-full " + t.bar} style={{ width: r.score + "%" }} /></div>
          <div className="text-[11px] text-slate-500 mt-1">Bar shows risk score (higher = riskier)</div>
        </div>
      </div>
      <div className="glass rounded-2xl p-4 sm:p-6">
        <div role="tablist" className="flex gap-1 overflow-x-auto pb-4 mb-4 border-b border-slate-800">
          {RT.map(([id, l, ic]) => <button key={id} role="tab" aria-selected={tab === id} onClick={() => setTab(id)} className={"flex items-center gap-2 px-3 py-2 rounded-lg text-sm whitespace-nowrap transition-colors " + (tab === id ? "bg-indigo-500/20 text-cyan-300 border border-indigo-400/40" : "text-slate-400 border border-transparent hover:text-white")}><Icon n={ic} s={16} />{l}</button>)}
        </div>
        <Panel r={r} tab={tab} />
      </div>
      <p className="text-center text-xs text-slate-600">{r.source === "demo" ? "Demo scenario: all analysis shown is simulated sample data." : "Live analysis from the Satya API. Automated results are indicative, not a final ruling."}</p>
    </div>
  );
}
