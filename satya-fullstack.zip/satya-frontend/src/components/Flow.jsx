import Icon from './Icon.jsx';

export const FEATURES = [
  { id: "temporal", icon: "clock", title: "Temporal Audit", desc: "Reverse-image search and original upload date" },
  { id: "ling", icon: "lang", title: "Linguistic Analysis", desc: "Sensationalism and emotional heatmap" },
  { id: "bot", icon: "bot", title: "Bot Swarm Risk", desc: "Synthetic amplification and automated accounts" },
  { id: "audio", icon: "wave", title: "Audio Analyzer", desc: "TTS and voice-clone spectrogram check" },
];

export default function Flow({ onPick, active }) {
  return (
    <section id="flow" className="px-4 py-14 max-w-6xl mx-auto">
      <h2 className="text-center text-2xl sm:text-3xl font-bold text-white">How Satya works</h2>
      <p className="text-center text-slate-400 mt-2">Every verification runs through four independent checks. Select one to open its analysis, or to start a new one.</p>
      <div className="relative mt-10">
        <div className="hidden lg:block absolute top-[46px] left-[12%] right-[12%] h-[2px] rounded flow-line opacity-70" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 relative">
          {FEATURES.map((f, i) => (
            <button key={f.id} onClick={() => onPick(f.id)}
              className={"glass rounded-2xl p-5 text-left transition-all hover:-translate-y-1 hover:border-cyan-400/50 hover:shadow-[0_0_30px_-8px_rgba(34,211,238,.5)] " + (active === f.id ? "border-cyan-400/60" : "")}>
              <span className="grid place-items-center w-12 h-12 rounded-xl bg-indigo-500/15 border border-indigo-400/40 text-cyan-300 mb-4 bg-[#0b0f19] relative"><Icon n={f.icon} s={22} /></span>
              <div className="text-xs text-slate-500">Step {i + 1}</div>
              <h3 className="font-semibold text-white mt-0.5">{f.title}</h3>
              <p className="text-sm text-slate-400 mt-1">{f.desc}</p>
              <span className="mt-3 inline-flex items-center gap-1 text-sm text-cyan-300">Open analysis <Icon n="arrow" s={14} /></span>
            </button>))}
        </div>
      </div>
    </section>
  );
}
