import { useState } from 'react';
import Icon from './Icon.jsx';
import { TONE } from './ui.jsx';
import { LIMITS } from '../services/api.js';

export const TABS = [["url", "Article URL", "link"], ["text", "Text / Claim / WhatsApp", "text"], ["image", "Image / Media", "image"], ["audio", "Audio / Voice Note", "mic"]];
const AUDIO_EXT = [".mp3", ".wav", ".m4a", ".ogg", ".opus", ".aac", ".webm"]; // mirrors routers/audio_verifier.py
const MIN_TEXT = 10; // backend TextRequest.min_length

/** Accepts "example.com/article" as well as full URLs; returns a normalized http(s) URL or null. */
function normalizeUrl(raw) {
  const v = raw.trim();
  if (!v || /\s/.test(v)) return null;
  const withScheme = /^https?:\/\//i.test(v) ? v : "https://" + v;
  try {
    const u = new URL(withScheme);
    return u.hostname.includes(".") ? u.toString() : null;
  } catch { return null; }
}

function validate(tab, vals, file) {
  if (tab === "url") return normalizeUrl(vals.url) ? null : "Enter a valid article link, e.g. https://example.com/news/story";
  if (tab === "text") return vals.text.trim().length >= MIN_TEXT ? null : `Enter at least ${MIN_TEXT} characters so there is a claim to check.`;
  if (!file) return "Choose a file first.";
  if (tab === "image") {
    if (!file.type.startsWith("image/")) return "Please choose an image file (JPEG, PNG, WebP or GIF).";
    if (file.size > LIMITS.imageMb * 1024 * 1024) return `Image is larger than ${LIMITS.imageMb} MB.`;
  } else {
    const ext = file.name.slice(file.name.lastIndexOf(".")).toLowerCase();
    if (!AUDIO_EXT.includes(ext)) return `Unsupported audio type. Allowed: ${AUDIO_EXT.join(", ")}`;
    if (file.size > LIMITS.audioMb * 1024 * 1024) return `Audio is larger than ${LIMITS.audioMb} MB.`;
  }
  return null;
}

export default function Hero({ tab, setTab, onVerify, loading, activeId, onDemo, demos }) {
  const [vals, setVals] = useState({ url: "", text: "" });
  const [files, setFiles] = useState({ image: null, audio: null });
  const [claimedDate, setClaimedDate] = useState("");
  const [localError, setLocalError] = useState("");
  const today = new Date().toISOString().slice(0, 10);
  const cta = { url: "Verify URL", text: "Verify Claim", image: "Verify Image", audio: "Verify Audio" }[tab];
  const file = files[tab];
  const ready = tab === "url" ? vals.url.trim().length > 3 : tab === "text" ? vals.text.trim().length > 0 : !!file;

  const set = (v) => { setVals({ ...vals, [tab]: v }); setLocalError(""); };
  const pick = (e) => { const f = e.target.files[0]; if (f) { setFiles({ ...files, [tab]: f }); setLocalError(""); } e.target.value = ""; };
  const submit = (e) => {
    e.preventDefault();
    if (loading) return;
    const err = validate(tab, vals, file);
    if (err) return setLocalError(err);
    setLocalError("");
    if (tab === "url") onVerify("url", normalizeUrl(vals.url));
    else if (tab === "text") onVerify("text", vals.text.trim());
    else if (tab === "image") onVerify("image", { file, claimedDate: claimedDate || null });
    else onVerify("audio", { file });
  };

  return (
    <section id="home" className="relative pt-14 pb-10 px-4 text-center">
      <div className="absolute inset-x-0 top-0 h-[480px] -z-10 bg-[radial-gradient(ellipse_at_top,rgba(99,102,241,.22),transparent_60%)]" />
      <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-white leading-[1.05]">Verify Anything.<br /><span className="glow-text">Trust the truth.</span></h1>
      <p className="mt-5 max-w-2xl mx-auto text-slate-400 text-base sm:text-lg">Multimodal fact-checking for articles, claims, images and voice notes — with explainable AI.</p>
      <form onSubmit={submit} className="glass rounded-2xl mt-9 max-w-3xl mx-auto p-3 sm:p-4 text-left shadow-[0_0_60px_-20px_rgba(129,140,248,.5)]">
        <div role="tablist" className="flex gap-1 overflow-x-auto pb-3">
          {TABS.map(([id, label, ic]) => (
            <button type="button" role="tab" aria-selected={tab === id} key={id} onClick={() => { setTab(id); setLocalError(""); }}
              className={"flex items-center gap-2 px-3 py-2 rounded-lg text-sm whitespace-nowrap transition-colors " + (tab === id ? "bg-indigo-500/20 text-cyan-300 border border-indigo-400/40" : "text-slate-400 border border-transparent hover:text-white hover:bg-slate-800/70")}>
              <Icon n={ic} s={16} />{label}
            </button>))}
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          {tab === "url" && <input type="text" inputMode="url" autoComplete="off" value={vals.url} onChange={(e) => set(e.target.value)} placeholder="https://example.com/news/article" className="flex-1 min-w-0 bg-slate-950/70 border border-slate-800 focus:border-cyan-400/60 outline-none rounded-xl px-4 py-3 text-slate-100 placeholder-slate-500" />}
          {tab === "text" && <textarea value={vals.text} onChange={(e) => set(e.target.value)} rows={3} maxLength={10000} placeholder="Paste a claim, headline or forwarded WhatsApp message…" className="flex-1 min-w-0 bg-slate-950/70 border border-slate-800 focus:border-cyan-400/60 outline-none rounded-xl px-4 py-3 text-slate-100 placeholder-slate-500 resize-none" />}
          {(tab === "image" || tab === "audio") && (
            <label className="flex-1 min-w-0 flex items-center justify-center gap-3 cursor-pointer bg-slate-950/70 border border-dashed border-slate-700 hover:border-cyan-400/60 rounded-xl px-4 py-5 text-slate-400">
              <Icon n="upload" />
              <span className="truncate">{file ? file.name : (tab === "image" ? "Drop an image, or click to browse" : "Drop a voice note, or click to browse")}</span>
              <input type="file" className="sr-only" accept={tab === "image" ? "image/*" : AUDIO_EXT.join(",") + ",audio/*"} onChange={pick} />
            </label>)}
          <button type="submit" disabled={!ready || loading}
            className="sm:self-stretch px-6 py-3 rounded-xl font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_0_28px_rgba(34,211,238,.55)] transition-all flex items-center justify-center gap-2">
            {loading ? <><span className="inline-block w-4 h-4 rounded-full border-2 border-slate-900/30 border-t-slate-900 animate-spin" />Analyzing…</> : <>{cta}<Icon n="arrow" s={16} /></>}
          </button>
        </div>
        {tab === "image" && (
          <label className="mt-3 flex flex-wrap items-center gap-2 text-sm text-slate-400">
            <span>When is this image being presented as taken? <span className="text-slate-500">(optional, defaults to today)</span></span>
            <input type="date" max={today} value={claimedDate} onChange={(e) => setClaimedDate(e.target.value)} className="bg-slate-950/70 border border-slate-800 focus:border-cyan-400/60 outline-none rounded-lg px-3 py-1.5 text-slate-100 [color-scheme:dark]" />
          </label>)}
        {localError && <p role="alert" className="mt-3 text-sm text-rose-300 bg-rose-500/10 border border-rose-500/30 rounded-lg px-3 py-2">{localError}</p>}
      </form>
      <div className="mt-5 flex flex-wrap items-center justify-center gap-2 max-w-3xl mx-auto">
        <span className="text-xs text-slate-500 mr-1">Try an offline demo:</span>
        {demos.map((s) => (
          <button key={s.id} onClick={() => onDemo(s.id)} disabled={loading}
            className={"text-xs sm:text-sm px-3 py-1.5 rounded-full border flex items-center gap-2 transition-all hover:scale-[1.03] disabled:opacity-50 " + TONE[s.tone].chip + (activeId === s.id ? " ring-2 ring-white/20" : "")}>
            <b>[{TONE[s.tone].label}]</b>{s.chip}
          </button>))}
      </div>
    </section>
  );
}
