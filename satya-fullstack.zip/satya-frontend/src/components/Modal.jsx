import { useEffect } from 'react';
import Icon from './Icon.jsx';

export function Modal({ title, onClose, children }) {
  useEffect(() => { const k = (e) => e.key === "Escape" && onClose(); window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k); }, []);
  return (
    <div className="fixed inset-0 z-50 grid place-items-center p-4 bg-black/60 backdrop-blur-sm rise" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div role="dialog" aria-modal="true" aria-label={title} className="pop w-full max-w-md max-h-[92vh] overflow-y-auto rounded-2xl bg-slate-900/80 backdrop-blur-xl border border-slate-800 p-6 shadow-[0_0_70px_-15px_rgba(129,140,248,.55)]">
        <div className="flex items-start justify-between gap-3 mb-5">
          <h2 className="text-lg font-semibold text-white leading-snug">{title}</h2>
          <button onClick={onClose} aria-label="Close" className="text-slate-500 hover:text-white p-1 -m-1"><Icon n="x" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

export const Spinner = ({ c = "w-5 h-5" }) => <span className={"inline-block rounded-full border-2 border-slate-600 border-t-cyan-400 animate-spin " + c} />;
export const FIELD = "w-full bg-slate-950/70 border border-slate-800 focus:border-cyan-400/60 outline-none rounded-xl pl-10 pr-3 py-2.5 text-slate-100 placeholder-slate-500";

export default Modal;
