import { useEffect, useState } from 'react';

const STEPS = {
  url: ["Fetching the article", "Extracting claims", "Cross-referencing fact-checkers", "Scoring language", "Scanning amplification"],
  text: ["Parsing the claim", "Cross-referencing fact-checkers", "Scoring language", "Scanning amplification"],
  image: ["Uploading image", "Reading EXIF metadata", "Running reverse-image search", "Checking for manipulation"],
  audio: ["Uploading audio", "Transcribing speech", "Analyzing voice signals", "Cross-referencing the spoken claim"],
};

// Glowing spinner + scan line while the real request is in flight. The step text is only a visual cue:
// it advances on a timer and parks on the last step until the API responds.
export default function Loading({ mode = "url" }) {
  const steps = STEPS[mode] || STEPS.url;
  const [i, setI] = useState(0);
  useEffect(() => {
    setI(0);
    const t = setInterval(() => setI((x) => Math.min(x + 1, steps.length - 1)), 2200);
    return () => clearInterval(t);
  }, [mode]);
  return (
    <div className="glass scan-wrap rounded-2xl p-10 text-center rise" role="status" aria-live="polite">
      <div className="scan-line" aria-hidden="true" />
      <div className="mx-auto w-12 h-12 rounded-full border-2 border-slate-700 border-t-cyan-400 animate-spin shadow-[0_0_28px_rgba(34,211,238,.45)]" />
      <p className="mt-5 text-white font-semibold">Analyzing with Satya Engine…</p>
      <p className="text-sm text-slate-400 mt-1">{steps[i]}</p>
      <div className="mt-4 h-1.5 max-w-xs mx-auto rounded bg-slate-800 overflow-hidden"><div className="h-full flow-line transition-all duration-700" style={{ width: Math.min(((i + 1) / steps.length) * 100, 92) + "%" }} /></div>
    </div>
  );
}
