import { useState } from 'react';
import Icon from './Icon.jsx';
import { Modal, Spinner, FIELD } from './Modal.jsx';

export default function AuthModal({ onClose, onLogin }) {
  const [mode, setMode] = useState("signin");
  const [f, setF] = useState({ name: "", email: "", pw: "", remember: true });
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState("");
  const up = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const finish = (name, email, kind) => { setBusy(kind); setTimeout(() => onLogin({ name, email }, f.remember), 900); };
  const submit = (e) => {
    e.preventDefault();
    if (busy) return;
    if (mode === "signup" && !f.name.trim()) return setErr("Enter your name to create an account.");
    if (!/^\S+@\S+\.\S+$/.test(f.email)) return setErr("Enter a valid email address.");
    if (f.pw.length < 6) return setErr("Password must be at least 6 characters.");
    setErr("");
    finish(f.name.trim() || f.email.split("@")[0], f.email, "form");
  };
  const social = (p) => !busy && finish(p + " User", p.toLowerCase() + "@demo.satya.ai", p);
  const up_ = mode === "signup";
  return (
    <Modal title={up_ ? "Create your Satya account" : "Sign in to Satya.ai"} onClose={onClose}>
      <div className="grid grid-cols-2 gap-2 mb-4">
        <button type="button" onClick={() => social("Google")} className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-slate-700 bg-slate-950/60 hover:border-cyan-400/50 text-sm text-slate-200 transition-colors">
          {busy === "Google" ? <Spinner c="w-4 h-4" /> : <b className="text-base bg-gradient-to-br from-sky-400 via-rose-400 to-amber-300 bg-clip-text text-transparent">G</b>}Continue with Google
        </button>
        <button type="button" onClick={() => social("GitHub")} className="flex items-center justify-center gap-2 py-2.5 rounded-xl border border-slate-700 bg-slate-950/60 hover:border-cyan-400/50 text-sm text-slate-200 transition-colors">
          {busy === "GitHub" ? <Spinner c="w-4 h-4" /> : <Icon n="github" s={16} />}Continue with GitHub
        </button>
      </div>
      <div className="flex items-center gap-3 text-xs text-slate-500 mb-4"><span className="h-px flex-1 bg-slate-800" />or use email<span className="h-px flex-1 bg-slate-800" /></div>
      <form onSubmit={submit} className="space-y-3" noValidate>
        {up_ && <div className="relative"><Icon n="user" s={16} c="absolute left-3.5 top-3.5 text-slate-500" /><input aria-label="Full name" value={f.name} onChange={up("name")} placeholder="Full name" className={FIELD} /></div>}
        <div className="relative"><Icon n="mail" s={16} c="absolute left-3.5 top-3.5 text-slate-500" /><input aria-label="Email address" type="email" value={f.email} onChange={up("email")} placeholder="Email address" autoComplete="email" className={FIELD} /></div>
        <div className="relative"><Icon n="lock" s={16} c="absolute left-3.5 top-3.5 text-slate-500" /><input aria-label="Password" type="password" value={f.pw} onChange={up("pw")} placeholder="Password" autoComplete={up_ ? "new-password" : "current-password"} className={FIELD} /></div>
        <div className="flex items-center justify-between text-sm">
          <label className="flex items-center gap-2 text-slate-300 cursor-pointer"><input type="checkbox" checked={f.remember} onChange={up("remember")} className="accent-cyan-400 w-4 h-4" />Remember me</label>
          {!up_ && <button type="button" className="text-cyan-300 hover:underline">Forgot password?</button>}
        </div>
        {err && <p role="alert" className="text-sm text-rose-300 bg-rose-500/10 border border-rose-500/30 rounded-lg px-3 py-2">{err}</p>}
        <button type="submit" disabled={!!busy} className="w-full py-2.5 rounded-xl font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 disabled:opacity-60 shadow-[0_0_24px_rgba(34,211,238,.45)] transition-all flex items-center justify-center gap-2">
          {busy === "form" ? <><Spinner c="w-4 h-4" />{up_ ? "Creating account…" : "Signing in…"}</> : up_ ? "Create Account" : "Sign In"}
        </button>
      </form>
      <p className="text-sm text-slate-400 text-center mt-4">{up_ ? "Already have an account?" : "New to Satya?"} <button type="button" onClick={() => { setMode(up_ ? "signin" : "signup"); setErr(""); }} className="text-cyan-300 font-medium hover:underline">{up_ ? "Sign In" : "Create Account"}</button></p>
      <p className="text-xs text-slate-600 text-center mt-3">Demo only: no credentials leave this page.</p>
    </Modal>
  );
}
