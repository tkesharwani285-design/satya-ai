import { useEffect, useState } from 'react';
import Icon from './Icon.jsx';
import { getHealth } from '../services/api.js';

// Polls GET /api/v1/health so the badge reflects the real backend (online/offline + average latency).
function useHealth(intervalMs = 15000) {
  const [health, setHealth] = useState(null); // null = checking, false = offline, object = online
  useEffect(() => {
    let alive = true;
    const ac = new AbortController();
    const ping = () => getHealth({ signal: ac.signal }).then((h) => alive && setHealth(h)).catch((e) => alive && e.kind !== 'aborted' && setHealth(false));
    ping();
    const t = setInterval(ping, intervalMs);
    return () => { alive = false; ac.abort(); clearInterval(t); };
  }, [intervalMs]);
  return health;
}

export default function Header({ user, onAuth, onSignOut, health }) {
  const online = !!health;
  const checking = health === null;
  return (
    <header className="sticky top-0 z-30 glass border-x-0 border-t-0">
      <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
        <a href="#home" className="flex items-center gap-2 font-semibold text-lg text-white">
          <span className="relative grid place-items-center w-9 h-9 rounded-xl bg-cyan-400/10 border border-cyan-400/40 text-cyan-300 shadow-[0_0_20px_rgba(34,211,238,.35)]">
            <Icon n="wave" c="pulse-dot" />
          </span>Satya<span className="text-cyan-300">.ai</span>
        </a>
        <nav className="hidden lg:flex items-center gap-1 text-sm text-slate-300">
          {[["Home", "home"], ["Features Flow", "flow"], ["WhatsApp Bot", "whatsapp"], ["Extension", "extension"], ["API Status", "api"]].map(([l, id]) => <a key={id} href={"#" + id} className="px-3 py-2 rounded-lg hover:bg-slate-800/80 hover:text-white transition-colors">{l}</a>)}
        </nav>
        <div className="flex items-center gap-2 sm:gap-3">
          <div className={"hidden sm:flex items-center gap-2 text-xs px-3 py-1.5 rounded-full border whitespace-nowrap " + (checking ? "border-slate-600 bg-slate-800/50 text-slate-300" : online ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-300" : "border-rose-500/40 bg-rose-500/10 text-rose-300")}>
            <span className={"w-2 h-2 rounded-full pulse-dot " + (checking ? "bg-slate-400" : online ? "bg-emerald-400" : "bg-rose-400")} />
            <span>{checking ? "Satya Core: Connecting…" : online ? "Satya Core: Active" : "Satya Core: Offline"}</span>
            {online && <><span className="text-slate-500">|</span><span>Latency: {health.latency_ms}ms</span></>}
          </div>
          {user ? (
            <div className="flex items-center gap-2">
              <span className="hidden md:inline-flex items-center gap-1.5 text-xs px-2.5 py-1.5 rounded-full border border-indigo-400/40 bg-indigo-500/15 text-indigo-200 whitespace-nowrap"><Icon n="shield" s={14} />Logged In (Pro Tier)</span>
              <span title={user.email} className="grid place-items-center w-9 h-9 rounded-full bg-gradient-to-br from-cyan-400 to-indigo-500 text-slate-950 font-bold shadow-[0_0_16px_rgba(34,211,238,.4)]">{user.name[0].toUpperCase()}</span>
              <button onClick={onSignOut} aria-label="Sign out" title="Sign out" className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"><Icon n="logout" s={16} /></button>
            </div>
          ) : (
            <button onClick={onAuth} className="px-4 py-2 rounded-lg text-sm font-medium text-cyan-200 border border-cyan-400/40 bg-cyan-400/10 hover:bg-cyan-400/20 transition-colors whitespace-nowrap">Sign In / Register</button>
          )}
        </div>
      </div>
    </header>
  );
}

export { useHealth };
