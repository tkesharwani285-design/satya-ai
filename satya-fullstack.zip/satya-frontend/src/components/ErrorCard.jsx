import Icon from './Icon.jsx';

export default function ErrorCard({ error, onRetry, onDismiss }) {
  if (!error) return null;
  const { message, kind } = error;
  const hint = kind === "network"
    ? "Start the backend with: uvicorn main:app --reload --port 8000 (see README)."
    : kind === "timeout" ? "Large files and slow sites can take a while. Try again, or try a smaller input." : null;
  return (
    <div role="alert" className="rise glass rounded-2xl p-6 border-rose-500/40 shadow-[0_0_40px_-10px_rgba(244,63,94,.5)]">
      <div className="flex items-start gap-3">
        <Icon n="alert" s={22} c="text-rose-400 mt-0.5 shrink-0" />
        <div className="flex-1 min-w-0">
          <h3 className="text-white font-semibold">We couldn’t complete that check</h3>
          <p className="text-slate-300 mt-1 break-words">{message}</p>
          {hint && <p className="text-sm text-slate-500 mt-2">{hint}</p>}
          <div className="mt-4 flex flex-wrap gap-2">
            {onRetry && <button onClick={onRetry} className="px-4 py-2 rounded-lg text-sm font-medium text-slate-950 bg-cyan-400 hover:bg-cyan-300 transition-colors">Try again</button>}
            <button onClick={onDismiss} className="px-4 py-2 rounded-lg text-sm text-slate-300 border border-slate-700 hover:text-white hover:bg-slate-800 transition-colors">Dismiss</button>
          </div>
        </div>
      </div>
    </div>
  );
}
