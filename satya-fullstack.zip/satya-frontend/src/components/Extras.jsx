import Icon from './Icon.jsx';

const INTEGRATIONS = [["google_factcheck", "Google Fact Check"], ["tavily", "Web search (Tavily)"], ["reverse_image", "Reverse-image search"], ["sarvam", "Sarvam transcription"], ["whisper", "Whisper transcription"], ["social_data", "Social data (bot risk)"]];

export default function Extras({ health }) {
  const items = [
    ["whatsapp", "chat", "WhatsApp Bot", "Forward any suspicious message to the Satya number and get a verdict, reasons and sources back in seconds."],
    ["extension", "puzzle", "Browser Extension", "Highlight text or right-click an image on any page for an inline trust badge, without leaving the article."],
    ["api", "server", "API Status", null],
  ];
  return (
    <section className="px-4 pb-16 max-w-6xl mx-auto grid md:grid-cols-3 gap-5">
      {items.map(([id, ic, t, d]) => (
        <div id={id} key={id} className="glass rounded-2xl p-5">
          <span className="grid place-items-center w-10 h-10 rounded-xl bg-cyan-400/10 border border-cyan-400/30 text-cyan-300 mb-3"><Icon n={ic} /></span>
          <h3 className="text-white font-semibold">{t}</h3>
          {d ? <p className="text-sm text-slate-400 mt-1">{d}</p> : (
            <ul className="mt-2 space-y-1.5 text-sm">
              <li className="flex justify-between text-slate-400"><span>Verification API</span>
                {health === null ? <span className="text-slate-400">Checking…</span> : health ? <span className="text-emerald-400 flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />Online · {health.version}</span> : <span className="text-rose-400 flex items-center gap-1.5"><span className="w-1.5 h-1.5 rounded-full bg-rose-400" />Offline</span>}</li>
              {health && INTEGRATIONS.map(([k, label]) => <li key={k} className="flex justify-between text-slate-400"><span>{label}</span><span className={health.integrations?.[k] ? "text-emerald-400" : "text-slate-500"}>{health.integrations?.[k] ? "Configured" : "Not configured"}</span></li>)}
            </ul>)}
        </div>))}
    </section>
  );
}
