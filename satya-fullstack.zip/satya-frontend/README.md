# Satya.ai frontend (Vite + React + Tailwind)

Talks to the FastAPI backend in `../satya-backend`.

## Run
```bash
npm install
npm run dev          # http://localhost:5173
```

## Configuration
`.env` (copy from `.env.example`):

| `VITE_API_BASE_URL` | Behaviour |
|---|---|
| `http://localhost:8000` (default) | Browser calls the backend directly. CORS is enabled for localhost in the backend. |
| *(empty value)* | Browser calls `/api/...` on the Vite server and `vite.config.js` proxies it to `http://localhost:8000`. No CORS involved. |
| `https://api.yourdomain.com` | Production: also add your frontend origin to `CORS_ORIGINS` in the backend. |

## Layout
- `src/services/api.js`: the only place that talks HTTP (`verifyUrl`, `verifyText`, `verifyMedia`, `verifyAudio`, `getBotRisk`, `getHealth`), with timeouts, cancellation and readable errors.
- `src/lib/adapt.js`: maps backend JSON to the dashboard view model.
- `src/App.jsx`: submits requests, owns `loading` / `error` / `result` state.
- `src/data/demo.js`: the offline demo chips (clearly labelled "Demo data").
