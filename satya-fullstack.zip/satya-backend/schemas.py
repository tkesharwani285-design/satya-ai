"""Pydantic request/response models shared by all routers."""
from typing import Literal, Optional

from pydantic import BaseModel, Field, HttpUrl, model_validator

Verdict = Literal["verified", "caution", "high_risk"]


def verdict_for(trust: int) -> Verdict:
    return "verified" if trust >= 70 else "caution" if trust >= 40 else "high_risk"


# ---------- shared ----------
class SourceReceipt(BaseModel):
    source: str
    status: Literal["true", "misleading", "false", "covered", "not_found", "unavailable"]
    title: Optional[str] = None
    url: Optional[str] = None
    rating: Optional[str] = None
    reviewed_on: Optional[str] = None


class PhraseHit(BaseModel):
    phrase: str
    category: Literal["sensational", "clickbait", "emotional", "urgency"]
    start: int
    end: int


class HeatmapSegment(BaseModel):
    text: str
    start: int
    end: int
    score: int = Field(ge=0, le=100)
    labels: list[str]


class LinguisticAnalysis(BaseModel):
    sensationalism: int
    clickbait: int
    emotional_bias: int
    neutrality: int
    heatmap: list[HeatmapSegment]
    highlighted_phrases: list[PhraseHit]


class GraphNode(BaseModel):
    id: str
    label: str
    type: Literal["claim", "entity", "source"]
    status: Optional[str] = None


class GraphEdge(BaseModel):
    source: str
    target: str
    relation: str


class ClaimGraph(BaseModel):
    nodes: list[GraphNode]
    edges: list[GraphEdge]


class ClaimResult(BaseModel):
    claim: str
    entities: list[str]
    consensus_truth: Optional[float] = None  # 0 = debunked, 1 = confirmed
    matches: int = 0


# ---------- text / url ----------
class TextRequest(BaseModel):
    text: str = Field(min_length=10, max_length=10000)


class UrlRequest(BaseModel):
    url: HttpUrl


class TextVerificationResponse(BaseModel):
    trust_score: int
    risk_score: int
    verdict: Verdict
    summary: str
    fact_check_coverage: Literal["found", "none", "unavailable"]
    linguistic: LinguisticAnalysis
    claims: list[ClaimResult]
    claim_graph: ClaimGraph
    source_receipts: list[SourceReceipt]


class ArticleInfo(BaseModel):
    title: str
    domain: str
    published: Optional[str] = None
    word_count: int
    excerpt: str


class UrlVerificationResponse(TextVerificationResponse):
    article: ArticleInfo


# ---------- media ----------
class MismatchAlert(BaseModel):
    status: Literal["mismatch", "consistent", "unknown"]
    message: str
    gap_days: Optional[int] = None


class ImageMatch(BaseModel):
    url: str
    title: Optional[str] = None
    published: Optional[str] = None


class MediaVerificationResponse(BaseModel):
    trust_score: int
    risk_score: int
    verdict: Verdict
    summary: str
    mismatch_alert: MismatchAlert
    original_upload_date: Optional[str] = None
    matched_source_url: Optional[str] = None
    manipulation_risk_score: int
    manipulation_signals: list[str]
    exif_present: bool
    exif: dict[str, str]
    reverse_search_status: Literal["ok", "no_matches", "unavailable"]
    matches: list[ImageMatch]


# ---------- audio ----------
class AudioSignal(BaseModel):
    name: str
    value: str
    flagged: bool
    note: str


class AudioVerificationResponse(BaseModel):
    trust_score: int
    risk_score: int
    verdict: Verdict
    summary: str
    synthetic_confidence: int
    spectrogram_status: Literal["natural_variation", "inconclusive", "synthetic_artifacts"]
    signals: list[AudioSignal]
    analyzed_seconds: float
    transcription_status: Literal["ok", "unavailable", "failed"]
    transcription: Optional[str] = None
    transcription_provider: Optional[str] = None
    transcription_language: Optional[str] = None
    transcription_english: Optional[str] = None  # translation the fact-check ran on (non-English audio)
    text_verification: Optional[TextVerificationResponse] = None


# ---------- bot risk ----------
class BotRiskRequest(BaseModel):
    claim_url: Optional[str] = Field(default=None, max_length=2048)
    hashtag: Optional[str] = Field(default=None, max_length=100)

    @model_validator(mode="after")
    def _one_required(self):
        if not (self.claim_url or self.hashtag):
            raise ValueError("Provide either 'claim_url' or 'hashtag'.")
        return self


class TimelinePoint(BaseModel):
    t: str
    count: int


class BotRiskResponse(BaseModel):
    query: str
    bot_activity_score: int
    risk_level: Literal["low", "moderate", "high"]
    account_spikes: int
    velocity_index: int
    new_account_ratio: int
    duplicate_text_ratio: int
    sentiment_coordination: int
    sample_size: int
    timeline: list[TimelinePoint]
    summary: str
    simulated: bool = False


# ---------- health ----------
class HealthResponse(BaseModel):
    status: Literal["ok"]
    engine: str
    version: str
    latency_ms: int
    uptime_seconds: int
    integrations: dict[str, bool]
