# Satya.ai Backend (FastAPI)

Multimodal misinformation-detection API: URLs, text/WhatsApp claims, images and voice notes.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # add whichever API keys you have
uvicorn main:app --reload --port 8000
```
Interactive docs: http://localhost:8000/docs. Audio needs `ffmpeg` on the PATH (the Dockerfile installs it).
Docker: `docker build -t satya-backend . && docker run -p 8000:8000 --env-file .env satya-backend`
Tests (no keys needed): `pip install pytest && python -m pytest tests -q`

## Endpoints (prefix `/api/v1`)
| Method | Path | Input | Key outputs |
|---|---|---|---|
| POST | `/verify/url` | `{"url": "..."}` | trust/risk score, verdict, summary, article info, source receipts, linguistic heatmap, claim graph |
| POST | `/verify/text` | `{"text": "..."}` | same as above without `article` |
| POST | `/verify/media` | multipart `file` (+ optional `claimed_date`) | mismatch alert, original upload date, matched source URL, manipulation risk, EXIF |
| POST | `/verify/audio` | multipart `file` (.mp3 .wav .m4a, plus .ogg/.opus for WhatsApp) | synthetic confidence %, spectrogram status, transcription, nested text verification |
| POST | `/verify/bot-risk` | `{"claim_url": "..."}` or `{"hashtag": "..."}` | bot activity score, account spikes, velocity index |
| GET | `/health` | | status, version `v2.4`, rolling latency, configured integrations |

```bash
curl -X POST localhost:8000/api/v1/verify/text -H 'Content-Type: application/json' \
  -d '{"text":"BREAKING: city is drowning, share before it gets deleted!"}'
curl -X POST localhost:8000/api/v1/verify/media -F file=@photo.jpg -F claimed_date=2026-10-18
```

## Configuration (`.env`)
Every key is optional; a missing key marks that integration `unavailable` in responses rather than failing.

| Variable | Enables |
|---|---|
| `GOOGLE_FACTCHECK_API_KEY` | Published fact-check ratings |
| `TAVILY_API_KEY` | Coverage search restricted to reuters.com, apnews.com, factcheck.org |
| `GOOGLE_VISION_API_KEY` | Reverse-image search (Web Detection) |
| `SARVAM_API_KEY` | Indian-language transcription (preferred when set): Saaras `saaras:v4`, plus English translation for fact-checking |
| `OPENAI_API_KEY` | Whisper transcription (used when no Sarvam key, or `TRANSCRIPTION_PROVIDER=openai`) |
| `X_BEARER_TOKEN` | Post data for bot-risk (X API v2 recent search) |
| `CORS_ORIGINS` / `CORS_ORIGIN_REGEX` | Frontend domains (defaults: localhost:5173 and :3000). With `ENVIRONMENT=development`, any `localhost` / `127.0.0.1` port is also allowed. |
| `ALLOW_SIMULATED` | Dev only: bot-risk returns data flagged `"simulated": true` when no provider is set |

## Design notes and limits
- **Heuristics, not verdicts.** Linguistic, image-forensics (error-level analysis) and audio scores are explainable indicators. Compressed phone audio can look synthetic and recycled-photo detection depends on the reverse-search index. Present results as risk signals.
- **Scoring.** With fact-check consensus: `risk = 0.8 * (1 - consensus) + 0.2 * language risk`. Without it, `risk = 25 + 0.5 * language risk`, so an unchecked claim is never shown as fully verified. Trust = 100 - risk.
- **URL fetching is SSRF-guarded**: only public addresses, every redirect re-validated, 2 MB cap. Add a rate limiter (e.g. slowapi or your gateway) and auth before exposing it publicly.
- Article extraction uses BeautifulSoup + lxml (not newspaper3k, which is unmaintained and sync-only).
- **Transcription:** `TRANSCRIPTION_PROVIDER=auto` uses Sarvam when `SARVAM_API_KEY` is set, otherwise OpenAI Whisper. Sarvam's sync API caps each request at 30 s, so audio is split into 28 s chunks (first 90 s only). For non-English speech the audio response includes `transcription_language`, the original `transcription`, and `transcription_english`, which is the text the fact-check and linguistic analysis actually ran on.
- **Indic text is not supported yet.** `/verify/text` and `/verify/url` lexicons are English-only, so Hindi/Tamil/etc. text will look artificially "neutral". Only audio is translated to English today.
- Bot-risk only runs on real data when a social provider is configured. Free X tiers are heavily limited.
