"""POST /api/v1/verify/audio: transcription, synthetic-speech heuristics, text verification."""
import asyncio
from pathlib import Path

import httpx
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile

from config import get_settings
from deps import get_http, read_limited
from schemas import AudioVerificationResponse, verdict_for
from services import audio_analysis as audio
from services import verification

router = APIRouter(prefix="/verify", tags=["verify"])
settings = get_settings()
ALLOWED = {".mp3", ".wav", ".m4a", ".ogg", ".opus", ".aac", ".webm"}  # .ogg/.opus = WhatsApp voice notes


@router.post("/audio", response_model=AudioVerificationResponse)
async def verify_audio(file: UploadFile = File(...), client: httpx.AsyncClient = Depends(get_http)):
    name = file.filename or "audio"
    ext = Path(name).suffix.lower()
    if ext not in ALLOWED:
        raise HTTPException(415, f"Unsupported audio type. Allowed: {', '.join(sorted(ALLOWED))}")
    data = await read_limited(file, settings.max_audio_mb)

    try:
        tr, (conf, signals, seconds) = await asyncio.gather(
            audio.transcribe(client, data, name), audio.analyze_file(data, ext))
    except ValueError as e:
        raise HTTPException(422, str(e))
    except RuntimeError as e:
        raise HTTPException(500, str(e))

    text_result = None
    claim_text = tr.english or tr.text  # fact-check the English translation when speech isn't English
    if claim_text and len(claim_text.split()) >= 3:
        text_result = await verification.verify_claim_text(client, claim_text.ljust(10))

    risk = round(0.65 * text_result.risk_score + 0.35 * conf) if text_result else conf
    trust = 100 - risk
    status = audio.status_for(conf)
    summary = (f"Synthetic-speech heuristics score {conf}% ({status.replace('_', ' ')}). "
               + (text_result.summary if text_result else
                  "No transcript was available, so the spoken claim was not fact-checked."))
    return AudioVerificationResponse(
        trust_score=trust, risk_score=risk, verdict=verdict_for(trust), summary=summary,
        synthetic_confidence=conf, spectrogram_status=status, signals=signals, analyzed_seconds=seconds,
        transcription_status=tr.status, transcription=tr.text, transcription_provider=tr.provider,
        transcription_language=tr.language, transcription_english=tr.english, text_verification=text_result)
