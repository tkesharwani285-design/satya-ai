"""POST /api/v1/verify/bot-risk: synthetic amplification analysis."""
import httpx
from fastapi import APIRouter, Depends, HTTPException

from config import get_settings
from deps import get_http
from schemas import BotRiskRequest, BotRiskResponse
from services import bot_analysis as bots

router = APIRouter(prefix="/verify", tags=["verify"])
settings = get_settings()


@router.post("/bot-risk", response_model=BotRiskResponse)
async def bot_risk(body: BotRiskRequest, client: httpx.AsyncClient = Depends(get_http)):
    if body.hashtag:
        query = "#" + body.hashtag.strip().lstrip("#")
    else:
        query = '"' + body.claim_url.strip().removeprefix("https://").removeprefix("http://") + '"'

    simulated = False
    try:
        posts = await bots.fetch_posts(client, query)
    except bots.ProviderError as e:
        raise HTTPException(e.status, e.message)
    except httpx.HTTPError:
        raise HTTPException(502, "Could not reach the social data provider.")
    if posts is None:
        if not settings.allow_simulated:
            raise HTTPException(503, "No social data provider configured (set X_BEARER_TOKEN).")
        posts, simulated = bots.simulate_posts(query), True

    if len(posts) < 5:
        return BotRiskResponse(query=query, bot_activity_score=0, risk_level="low", account_spikes=0,
                               velocity_index=0, new_account_ratio=0, duplicate_text_ratio=0,
                               sentiment_coordination=0, sample_size=len(posts), timeline=[],
                               summary="Too few public posts found to assess amplification.", simulated=simulated)

    s = bots.score(posts)
    level = "high" if s["score"] >= 60 else "moderate" if s["score"] >= 30 else "low"
    summary = (f"{s['new']}% of participating accounts are under 30 days old and {s['dup']}% of posts are "
               f"near-duplicates; peak posting velocity index is {s['velocity']}/100 across {len(posts)} sampled posts.")
    return BotRiskResponse(
        query=query, bot_activity_score=s["score"], risk_level=level, account_spikes=s["spikes"],
        velocity_index=s["velocity"], new_account_ratio=s["new"], duplicate_text_ratio=s["dup"],
        sentiment_coordination=s["coord"], sample_size=len(posts), timeline=s["timeline"],
        summary=summary + (" (Simulated demo data.)" if simulated else ""), simulated=simulated)
