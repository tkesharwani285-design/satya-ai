"""POST /api/v1/verify/media: EXIF + reverse-image temporal audit."""
import asyncio
from datetime import date, datetime, timezone

import httpx
from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile

from config import get_settings
from deps import get_http, read_limited
from schemas import MediaVerificationResponse, verdict_for
from services import media_analysis as media

router = APIRouter(prefix="/verify", tags=["verify"])
settings = get_settings()


@router.post("/media", response_model=MediaVerificationResponse)
async def verify_media(
    file: UploadFile = File(..., description="Image file (JPEG/PNG/WebP/GIF)"),
    claimed_date: date | None = Form(None, description="When the image is being presented as taken (default: today)"),
    client: httpx.AsyncClient = Depends(get_http),
):
    data = await read_limited(file, settings.max_image_mb)
    try:
        img = await asyncio.to_thread(media.load_image, data)
    except ValueError as e:
        raise HTTPException(415, str(e))

    exif = media.read_exif(img)
    (manip, signals), jpeg = await asyncio.gather(
        asyncio.to_thread(media.manipulation_analysis, img, exif),
        asyncio.to_thread(media.prepare_for_search, img))
    status, found = await media.reverse_search(client, jpeg)

    claimed = claimed_date or datetime.now(timezone.utc).date()
    dated = [(m, d) for m, d in found if d]
    web_date = min((d for _, d in dated), default=None)
    alert, earliest = media.assess_mismatch(web_date, media.exif_date(exif), claimed, status)
    source = next((m.url for m, d in dated if d == web_date), None) if web_date else None

    base = {"mismatch": 80, "consistent": 10, "unknown": 30}[alert.status]
    risk = round(0.6 * base + 0.4 * manip)
    trust = 100 - risk
    summary = alert.message + (f" Manipulation indicators: {manip}/100." if manip else "")
    return MediaVerificationResponse(
        trust_score=trust, risk_score=risk, verdict=verdict_for(trust), summary=summary,
        mismatch_alert=alert, original_upload_date=earliest.date().isoformat() if earliest else None,
        matched_source_url=source, manipulation_risk_score=manip, manipulation_signals=signals,
        exif_present=bool(exif), exif=exif, reverse_search_status=status, matches=[m for m, _ in found])
