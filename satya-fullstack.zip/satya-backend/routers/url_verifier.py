"""POST /api/v1/verify/url: scrape article, then run the claim pipeline on it."""
import httpx
from fastapi import APIRouter, Depends, HTTPException

from deps import get_http
from schemas import ArticleInfo, UrlRequest, UrlVerificationResponse
from services import scraper, verification

router = APIRouter(prefix="/verify", tags=["verify"])


@router.post("/url", response_model=UrlVerificationResponse)
async def verify_url(body: UrlRequest, client: httpx.AsyncClient = Depends(get_http)):
    try:
        final_url, html = await scraper.fetch_html(client, str(body.url))
    except scraper.FetchError as e:
        raise HTTPException(e.status, e.message)

    art = scraper.extract_article(html, final_url)
    words = len(art["text"].split())
    if words < 25:
        raise HTTPException(422, "Could not extract readable article text from this page.")

    text = f"{art['title']}. {art['text'][:6000]}"
    result = await verification.verify_claim_text(client, text, priority_claims=[art["title"]])
    pub = art["published"]
    return UrlVerificationResponse(
        **result.model_dump(),
        article=ArticleInfo(title=art["title"], domain=art["domain"], word_count=words,
                            published=pub.date().isoformat() if pub else None, excerpt=art["text"][:300]))
