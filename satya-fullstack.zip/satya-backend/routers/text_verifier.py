"""POST /api/v1/verify/text: linguistic heatmap + claim cross-referencing."""
import httpx
from fastapi import APIRouter, Depends

from deps import get_http
from schemas import TextRequest, TextVerificationResponse
from services import verification

router = APIRouter(prefix="/verify", tags=["verify"])


@router.post("/text", response_model=TextVerificationResponse)
async def verify_text(body: TextRequest, client: httpx.AsyncClient = Depends(get_http)):
    return await verification.verify_claim_text(client, body.text)
