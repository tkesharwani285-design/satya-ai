"""Shared FastAPI dependencies and helpers."""
import httpx
from fastapi import HTTPException, Request, UploadFile


def get_http(request: Request) -> httpx.AsyncClient:
    return request.app.state.http


async def read_limited(file: UploadFile, max_mb: int) -> bytes:
    limit = max_mb * 1024 * 1024
    data = await file.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(413, f"File exceeds the {max_mb} MB limit.")
    if not data:
        raise HTTPException(422, "Uploaded file is empty.")
    return data
