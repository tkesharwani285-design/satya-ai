"""Settings and API keys, loaded from environment / .env."""
from functools import lru_cache

from dotenv import load_dotenv
from pydantic_settings import BaseSettings, SettingsConfigDict

load_dotenv()


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "Satya.ai Verification Engine"
    version: str = "v2.4"
    environment: str = "development"

    cors_origins: str = "http://localhost:5173,http://localhost:3000"
    cors_origin_regex: str = ""

    google_factcheck_api_key: str = ""
    tavily_api_key: str = ""
    google_vision_api_key: str = ""
    openai_api_key: str = ""
    whisper_model: str = "whisper-1"
    sarvam_api_key: str = ""
    sarvam_stt_model: str = "saaras:v4"
    transcription_provider: str = "auto"  # auto | sarvam | openai
    x_bearer_token: str = ""

    allow_simulated: bool = False
    http_timeout: float = 15.0
    max_image_mb: int = 10
    max_audio_mb: int = 25

    @property
    def origins(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
