"""Offline smoke tests (no API keys needed). Run: python -m pytest tests -q"""
import io
import os
import sys
import wave

import numpy as np
from fastapi.testclient import TestClient
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
os.environ["ALLOW_SIMULATED"] = "true"

from main import app  # noqa: E402
from services import scraper  # noqa: E402

ARTICLE = ("<html><head><title>Flood hits city</title><meta property='article:published_time' content='2026-10-01T10:00:00Z'>"
           "</head><body><article>" + "".join(
               f"<p>Officials said the river rose by {i + 3} metres on Monday according to the state agency report today.</p>"
               for i in range(6)) + "</article></body></html>")


def test_health_and_cors():
    with TestClient(app) as c:
        r = c.get("/api/v1/health", headers={"Origin": "http://localhost:5173"})
        assert r.status_code == 200 and r.json()["version"] == "v2.4"
        assert r.headers["access-control-allow-origin"] == "http://localhost:5173"


def test_text_sensational_scores_worse_than_neutral():
    with TestClient(app) as c:
        bad = c.post("/api/v1/verify/text", json={"text": "BREAKING!!! SHOCKING bombshell! Share this before it gets deleted, they are hiding the truth!"}).json()
        ok = c.post("/api/v1/verify/text", json={"text": "The central bank said on Tuesday it kept the repo rate at 6.5 percent, according to its statement."}).json()
        assert bad["linguistic"]["sensationalism"] > ok["linguistic"]["sensationalism"]
        assert bad["trust_score"] < ok["trust_score"]
        assert bad["linguistic"]["highlighted_phrases"] and bad["source_receipts"][0]["status"] == "unavailable"
        assert c.post("/api/v1/verify/text", json={"text": "short"}).status_code == 422


def test_url_ssrf_blocked_and_extraction(monkeypatch):
    with TestClient(app) as c:
        assert c.post("/api/v1/verify/url", json={"url": "http://127.0.0.1:8000/x"}).status_code == 422

        async def fake(client, url, max_bytes=0):
            return url, ARTICLE
        monkeypatch.setattr(scraper, "fetch_html", fake)
        r = c.post("/api/v1/verify/url", json={"url": "https://example.com/a"})
        assert r.status_code == 200, r.text
        assert r.json()["article"]["published"] == "2026-10-01" and r.json()["article"]["title"] == "Flood hits city"


def test_media_exif_mismatch():
    img = Image.new("RGB", (320, 240), (90, 120, 200))
    exif = Image.Exif()
    exif[0x0132] = "2018:08:14 10:00:00"
    exif[0x9003] = "2018:08:14 10:00:00"
    exif[0x0131] = "Adobe Photoshop 24"
    buf = io.BytesIO()
    img.save(buf, "JPEG", exif=exif)
    with TestClient(app) as c:
        r = c.post("/api/v1/verify/media", files={"file": ("a.jpg", buf.getvalue(), "image/jpeg")})
        j = r.json()
        assert r.status_code == 200, r.text
        assert j["mismatch_alert"]["status"] == "mismatch" and j["original_upload_date"] == "2018-08-14"
        assert j["manipulation_risk_score"] >= 30
        assert c.post("/api/v1/verify/media", files={"file": ("a.jpg", b"notimage", "image/jpeg")}).status_code == 415


def _wav(samples):
    b = io.BytesIO()
    with wave.open(b, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(22050)
        w.writeframes((samples * 32000).astype(np.int16).tobytes())
    return b.getvalue()


def test_audio_flat_tone_scores_synthetic_and_natural_lower():
    t = np.arange(22050 * 8) / 22050
    flat = 0.5 * np.sin(2 * np.pi * 140 * t)  # constant pitch, digital silence floor
    rng = np.random.default_rng(0)
    f0 = 130 + 40 * np.sin(2 * np.pi * 0.7 * t) + 15 * np.sin(2 * np.pi * 2.3 * t)
    env = (np.sin(2 * np.pi * 0.6 * t) > -0.3) * 1.0
    natural = 0.4 * env * np.sin(2 * np.pi * np.cumsum(f0) / 22050) + 0.004 * rng.standard_normal(len(t))
    with TestClient(app) as c:
        a = c.post("/api/v1/verify/audio", files={"file": ("f.wav", _wav(flat), "audio/wav")}).json()
        b = c.post("/api/v1/verify/audio", files={"file": ("n.wav", _wav(natural), "audio/wav")}).json()
        assert a["synthetic_confidence"] > b["synthetic_confidence"], (a["synthetic_confidence"], b["synthetic_confidence"])
        assert a["transcription_status"] == "unavailable"
        assert c.post("/api/v1/verify/audio", files={"file": ("x.txt", b"hi", "text/plain")}).status_code == 415


def test_bot_risk_simulated_and_validation():
    with TestClient(app) as c:
        r = c.post("/api/v1/verify/bot-risk", json={"hashtag": "#FloodFake"})
        j = r.json()
        assert r.status_code == 200 and j["simulated"] and 0 <= j["bot_activity_score"] <= 100 and j["timeline"]
        assert c.post("/api/v1/verify/bot-risk", json={}).status_code == 422


def test_factcheck_google_and_tavily_mocked(monkeypatch):
    from services import factcheck_api as fc
    monkeypatch.setattr(fc.settings, "google_factcheck_api_key", "x")
    monkeypatch.setattr(fc.settings, "tavily_api_key", "x")

    async def g(client, q):
        return [{"publisher": "Snopes", "site": "snopes.com", "url": "https://snopes.com/a", "title": "Old flood photo",
                 "rating": "Mostly False", "date": "2026-10-02"},
                {"publisher": "AP", "site": "apnews.com", "url": "https://apnews.com/b", "title": "AP Fact Check",
                 "rating": "False", "date": "2026-10-03"}]

    async def t(client, q):
        return [{"url": "https://www.reuters.com/fact-check/x", "title": "Fact check: photo is misleading", "content": ""}]
    monkeypatch.setattr(fc, "_google", g)
    monkeypatch.setattr(fc, "_tavily", t)
    with TestClient(app) as c:
        j = c.post("/api/v1/verify/text", json={"text": "Photo shows the 2026 flood in the city, officials said on Monday."}).json()
        st = {r["source"]: r["status"] for r in j["source_receipts"]}
        assert st["AP News"] == "false" and st["Reuters"] == "misleading" and st["FactCheck.org"] == "not_found"
        assert j["fact_check_coverage"] == "found" and j["verdict"] == "high_risk" and j["claim_graph"]["edges"]


def test_sarvam_chunking_headers_and_translation(monkeypatch):
    """Long Hindi voice note: 2 chunks (30 s cap), correct auth header, translate mode used for fact-checking."""
    import httpx
    from services import audio_analysis as aa
    monkeypatch.setattr(aa.settings, "sarvam_api_key", "test-key")
    calls = []

    def handler(request: httpx.Request) -> httpx.Response:
        body = request.content
        mode = "translate" if b'name="mode"\r\n\r\ntranslate' in body else "transcribe"
        calls.append((request.url.path, request.headers.get("api-subscription-key"), mode, b"saaras:v4" in body))
        text = "BREAKING shocking news share before it gets deleted" if mode == "translate" else "ब्रेकिंग खबर"
        return httpx.Response(200, json={"request_id": "r", "transcript": text, "language_code": "hi-IN"})

    t = np.arange(22050 * 40) / 22050
    audio_bytes = _wav(0.4 * np.sin(2 * np.pi * (140 + 30 * np.sin(2 * np.pi * 0.5 * t)) * t))
    with TestClient(app) as c:
        app.state.http = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        j = c.post("/api/v1/verify/audio", files={"file": ("v.wav", audio_bytes, "audio/wav")}).json()
    assert j["transcription_provider"] == "sarvam" and j["transcription_language"] == "hi-IN"
    assert j["transcription"].startswith("ब्रेकिंग") and j["transcription_english"].startswith("BREAKING")
    assert sum(m == "transcribe" for *_, m, _ in [(x[0], x[1], x[2], x[3]) for x in calls]) == 2  # 40 s -> 2 chunks
    assert sum(x[2] == "translate" for x in calls) == 2
    assert all(x[0] == "/speech-to-text" and x[1] == "test-key" and x[3] for x in calls)
    assert j["text_verification"]["linguistic"]["sensationalism"] > 0  # English lexicon ran on the translation
