"""Fact-check lookups: Google Fact Check Tools API + Tavily (restricted to trusted outlets)."""
import asyncio
import logging
import re
from dataclasses import dataclass
from urllib.parse import urlparse

import httpx

from config import get_settings
from schemas import SourceReceipt

log = logging.getLogger("satya.factcheck")
settings = get_settings()

TRUSTED = {"Reuters": "reuters.com", "AP News": "apnews.com", "FactCheck.org": "factcheck.org"}
GOOGLE_URL = "https://factchecktools.googleapis.com/v1alpha1/claims:search"
TAVILY_URL = "https://api.tavily.com/search"

_NEG = re.compile(r"\b(?:false|fake|fabricated|hoax|pants on fire|incorrect|debunk\w*|scam|not true|no evidence|baseless)\b", re.I)
_MID = re.compile(r"\b(?:misleading|mostly false|half[- ]true|missing context|out of context|altered|unproven|exaggerat\w*|partly|mixture|satire|outdated|miscaptioned)\b", re.I)
_POS = re.compile(r"\b(?:true|correct|accurate|legit|confirmed)\b", re.I)


@dataclass
class FactCheckResult:
    receipts: list[SourceReceipt]
    consensus: float | None  # 0 = debunked ... 1 = confirmed
    matches: int
    coverage: str  # found | none | unavailable


def rating_to_truth(rating: str) -> float | None:
    if re.search(r"mostly true", rating, re.I):
        return 0.8
    if re.search(r"mostly false", rating, re.I):
        return 0.2
    if _MID.search(rating):
        return 0.35
    if _NEG.search(rating):
        return 0.05
    if _POS.search(rating):
        return 1.0
    return None


def _status(truth: float) -> str:
    return "false" if truth <= 0.15 else "misleading" if truth <= 0.5 else "true"


def _name_for(url_or_site: str | None) -> str | None:
    host = (urlparse(url_or_site if "//" in (url_or_site or "") else f"//{url_or_site}").hostname or "").lower()
    for name, domain in TRUSTED.items():
        if host == domain or host.endswith("." + domain):
            return name
    return None


async def _google(client: httpx.AsyncClient, query: str) -> list[dict] | None:
    if not settings.google_factcheck_api_key:
        return None
    try:
        r = await client.get(GOOGLE_URL, params={"query": query[:250], "key": settings.google_factcheck_api_key, "pageSize": 8})
        r.raise_for_status()
    except httpx.HTTPError as e:
        log.warning("Google Fact Check failed: %s", e)
        return None
    out = []
    for claim in r.json().get("claims", []):
        for rev in claim.get("claimReview", []):
            pub = rev.get("publisher", {})
            out.append({"publisher": pub.get("name"), "site": pub.get("site") or rev.get("url"),
                        "url": rev.get("url"), "title": rev.get("title") or claim.get("text"),
                        "rating": rev.get("textualRating") or "", "date": (rev.get("reviewDate") or "")[:10] or None})
    return out


async def _tavily(client: httpx.AsyncClient, query: str) -> list[dict] | None:
    if not settings.tavily_api_key:
        return None
    try:
        r = await client.post(TAVILY_URL, headers={"Authorization": f"Bearer {settings.tavily_api_key}"},
                              json={"query": query[:300], "include_domains": list(TRUSTED.values()),
                                    "max_results": 8, "search_depth": "basic"})
        r.raise_for_status()
    except httpx.HTTPError as e:
        log.warning("Tavily search failed: %s", e)
        return None
    return r.json().get("results", [])


async def lookup(client: httpx.AsyncClient, query: str) -> FactCheckResult:
    g, t = await asyncio.gather(_google(client, query), _tavily(client, query))
    if g is None and t is None:
        return FactCheckResult([SourceReceipt(source=n, status="unavailable") for n in TRUSTED], None, 0, "unavailable")

    receipts: dict[str, SourceReceipt] = {}
    truths: list[float] = []
    for rev in g or []:
        truth = rating_to_truth(rev["rating"])
        if truth is not None:
            truths.append(truth)
        name = _name_for(rev["site"]) or rev["publisher"] or "Fact-checker"
        receipts.setdefault(name, SourceReceipt(
            source=name, status=_status(truth) if truth is not None else "covered",
            title=rev["title"], url=rev["url"], rating=rev["rating"] or None, reviewed_on=rev["date"]))
    for item in t or []:
        name = _name_for(item.get("url"))
        if not name or name in receipts:
            continue
        blob = f"{item.get('title', '')} {item.get('content', '')[:400]}"
        debunk = bool(_NEG.search(blob) or _MID.search(blob))
        if debunk:
            truths.append(0.3)
        receipts[name] = SourceReceipt(source=name, status="misleading" if debunk else "covered",
                                       title=item.get("title"), url=item.get("url"))

    missing = "unavailable" if t is None else "not_found"
    ordered = [receipts.pop(n) if n in receipts else SourceReceipt(source=n, status=missing) for n in TRUSTED]
    ordered += list(receipts.values())[:3]
    matches = len(g or []) + len(t or [])
    return FactCheckResult(ordered, sum(truths) / len(truths) if truths else None, matches,
                           "found" if matches else "none")
