"""SSRF-safe page fetching and article/date extraction (BeautifulSoup)."""
import asyncio
import ipaddress
import json
import re
import socket
from datetime import datetime, timezone
from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup
from dateutil import parser as dtparse


class FetchError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status, self.message = status, message


async def assert_public_url(url: str) -> None:
    p = urlparse(url)
    if p.scheme not in ("http", "https") or not p.hostname:
        raise FetchError(422, "Only http(s) URLs are supported.")
    try:
        infos = await asyncio.get_running_loop().getaddrinfo(
            p.hostname, p.port or (443 if p.scheme == "https" else 80), type=socket.SOCK_STREAM)
    except socket.gaierror:
        raise FetchError(422, "Could not resolve the URL's host.")
    if any(not ipaddress.ip_address(i[4][0]).is_global for i in infos):
        raise FetchError(422, "URL points to a non-public address.")


async def fetch_html(client: httpx.AsyncClient, url: str, max_bytes: int = 2_000_000) -> tuple[str, str]:
    """Fetch HTML, validating every redirect hop against private address ranges."""
    try:
        for _ in range(4):
            await assert_public_url(url)
            async with client.stream("GET", url, follow_redirects=False,
                                     headers={"Accept": "text/html,application/xhtml+xml"}) as r:
                if r.is_redirect:
                    loc = r.headers.get("location")
                    if not loc:
                        raise FetchError(502, "Redirect without a target.")
                    url = urljoin(url, loc)
                    continue
                if r.status_code >= 400:
                    raise FetchError(502, f"The page returned HTTP {r.status_code}.")
                if "html" not in r.headers.get("content-type", "").lower():
                    raise FetchError(415, "URL does not point to an HTML page.")
                buf = bytearray()
                async for chunk in r.aiter_bytes():
                    buf += chunk
                    if len(buf) > max_bytes:
                        break
                return url, bytes(buf).decode(r.encoding or "utf-8", errors="replace")
        raise FetchError(502, "Too many redirects.")
    except httpx.HTTPError as e:
        raise FetchError(502, f"Could not fetch the page ({type(e).__name__}).")


def parse_date(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        d = dtparse.parse(value.strip())
    except (ValueError, OverflowError):
        return None
    if d.tzinfo:
        d = d.astimezone(timezone.utc).replace(tzinfo=None)
    return d if 1990 <= d.year <= datetime.now().year + 1 else None


_META_KEYS = ("article:published_time", "og:article:published_time", "datePublished", "pubdate",
              "date", "DC.date.issued", "parsely-pub-date", "sailthru.date")


def find_date(soup: BeautifulSoup) -> datetime | None:
    for key in _META_KEYS:
        tag = soup.find("meta", attrs={"property": key}) or soup.find("meta", attrs={"name": key}) \
            or soup.find("meta", attrs={"itemprop": key})
        if tag and (d := parse_date(tag.get("content"))):
            return d
    for script in soup.find_all("script", type="application/ld+json"):
        m = re.search(r'"datePublished"\s*:\s*"([^"]+)"', script.string or "")
        if m and (d := parse_date(m.group(1))):
            return d
    t = soup.find("time", attrs={"datetime": True})
    return parse_date(t["datetime"]) if t else None


def extract_article(html: str, url: str) -> dict:
    soup = BeautifulSoup(html, "lxml")
    og = soup.find("meta", attrs={"property": "og:title"})
    title = (og.get("content") if og else None) or (soup.title.string if soup.title and soup.title.string else "") \
        or (soup.h1.get_text(" ", strip=True) if soup.h1 else "")
    published = find_date(soup)
    for t in soup(["script", "style", "nav", "footer", "header", "aside", "form", "noscript"]):
        t.decompose()
    container = soup.find("article") or soup.find("main") or soup.body or soup
    paras = [p.get_text(" ", strip=True) for p in container.find_all("p")]
    text = "\n".join(p for p in paras if len(p.split()) >= 6)
    return {"title": title.strip()[:300], "text": text, "published": published,
            "domain": (urlparse(url).hostname or "").removeprefix("www.")}


async def page_date(client: httpx.AsyncClient, url: str) -> datetime | None:
    try:
        _, html = await fetch_html(client, url, max_bytes=600_000)
    except FetchError:
        return None
    return find_date(BeautifulSoup(html, "lxml"))
