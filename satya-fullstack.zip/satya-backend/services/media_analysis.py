"""Image audit: EXIF, error-level-analysis heuristics and reverse-image search (Google Vision)."""
import asyncio
import base64
import io
import logging
from datetime import date, datetime

import httpx
import numpy as np
from PIL import ExifTags, Image, ImageChops, UnidentifiedImageError

from config import get_settings
from schemas import ImageMatch, MismatchAlert
from services.scraper import page_date

log = logging.getLogger("satya.media")
settings = get_settings()
Image.MAX_IMAGE_PIXELS = 60_000_000  # decompression-bomb guard

_WANTED = {"Make", "Model", "Software", "DateTime", "DateTimeOriginal", "DateTimeDigitized",
           "LensModel", "ExposureTime", "FNumber", "ISOSpeedRatings", "ImageUniqueID"}
_EDITORS = ("photoshop", "gimp", "canva", "pixelmator", "lightroom", "snapseed", "picsart",
            "facetune", "affinity", "stable diffusion", "midjourney", "dall")


def load_image(data: bytes) -> Image.Image:
    try:
        img = Image.open(io.BytesIO(data))
        img.load()
        return img
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        raise ValueError("File is not a valid or supported image.")


def read_exif(img: Image.Image) -> dict[str, str]:
    out: dict[str, str] = {}
    exif = img.getexif()
    merged = dict(exif)
    try:
        merged.update(exif.get_ifd(0x8769))
        if exif.get_ifd(0x8825):
            out["GPSInfo"] = "present (coordinates not returned)"
    except Exception:
        pass
    for tag, val in merged.items():
        name = ExifTags.TAGS.get(tag, str(tag))
        if name in _WANTED:
            out[name] = str(val).strip("\x00")[:120]
    return out


def exif_date(exif: dict[str, str]) -> datetime | None:
    for key in ("DateTimeOriginal", "DateTimeDigitized", "DateTime"):
        try:
            return datetime.strptime(exif[key], "%Y:%m:%d %H:%M:%S")
        except (KeyError, ValueError):
            continue
    return None


def manipulation_analysis(img: Image.Image, exif: dict[str, str]) -> tuple[int, list[str]]:
    """Heuristic indicators only; not proof of tampering."""
    risk, signals = 0, []
    software = exif.get("Software", "")
    if any(k in software.lower() for k in _EDITORS):
        risk += 30
        signals.append(f"Processed with editing/generation software: {software}")
    if not exif:
        risk += 10
        signals.append("No EXIF metadata (stripped or re-encoded, common for social-media reposts)")
    if img.format in ("JPEG", "WEBP", None) or img.mode in ("RGB", "RGBA", "L"):
        rgb = img.convert("RGB")
        rgb.thumbnail((1024, 1024))
        buf = io.BytesIO()
        rgb.save(buf, "JPEG", quality=90)
        buf.seek(0)
        diff = np.asarray(ImageChops.difference(rgb, Image.open(buf)).convert("L"), dtype=np.float32)
        h, w = diff.shape
        bh, bw = max(h // 8, 1), max(w // 8, 1)
        blocks = np.array([diff[y:y + bh, x:x + bw].mean()
                           for y in range(0, h - bh + 1, bh) for x in range(0, w - bw + 1, bw)])
        ratio = blocks.max() / (np.median(blocks) + 1e-6)
        cv = blocks.std() / (blocks.mean() + 1e-6)
        if ratio > 6 and cv > 0.8:
            risk += 35
            signals.append("Localized error-level inconsistency (possible spliced or retouched region)")
        elif ratio > 3.5:
            risk += 15
            signals.append("Mild error-level variation across the image")
    if not signals:
        signals.append("No strong manipulation indicators found")
    return min(100, risk), signals


def prepare_for_search(img: Image.Image) -> bytes:
    rgb = img.convert("RGB")
    rgb.thumbnail((1600, 1600))
    buf = io.BytesIO()
    rgb.save(buf, "JPEG", quality=88)
    return buf.getvalue()


async def reverse_search(client: httpx.AsyncClient, jpeg: bytes) -> tuple[str, list[tuple[ImageMatch, datetime | None]]]:
    key = settings.google_vision_api_key
    if not key:
        return "unavailable", []
    body = {"requests": [{"image": {"content": base64.b64encode(jpeg).decode()},
                          "features": [{"type": "WEB_DETECTION", "maxResults": 10}]}]}
    try:
        r = await client.post("https://vision.googleapis.com/v1/images:annotate", params={"key": key},
                              json=body, timeout=30)
        r.raise_for_status()
        web = r.json()["responses"][0].get("webDetection", {})
    except (httpx.HTTPError, KeyError, IndexError, ValueError) as e:
        log.warning("Vision web detection failed: %s", e)
        return "unavailable", []
    pages = [p for p in web.get("pagesWithMatchingImages", []) if p.get("url")][:6]
    if not pages:
        return "no_matches", []
    dates = await asyncio.gather(*(page_date(client, p["url"]) for p in pages), return_exceptions=True)
    out = []
    for p, d in zip(pages, dates):
        d = d if isinstance(d, datetime) else None
        out.append((ImageMatch(url=p["url"], title=p.get("pageTitle"),
                               published=d.date().isoformat() if d else None), d))
    return "ok", out


def assess_mismatch(web_date: datetime | None, cam_date: datetime | None, claimed: date,
                    status: str) -> tuple[MismatchAlert, datetime | None]:
    """Compare the earliest known appearance against when the image is being presented."""
    candidates = [("an indexed web page", web_date), ("the camera timestamp (EXIF)", cam_date)]
    candidates = [(src, d) for src, d in candidates if d]
    if not candidates:
        msg = ("Reverse-image search is not configured; no EXIF date available." if status == "unavailable"
               else "No dated earlier appearances were found, so recycling cannot be confirmed.")
        return MismatchAlert(status="unknown", message=msg), None
    src, earliest = min(candidates, key=lambda c: c[1])
    gap = (claimed - earliest.date()).days
    if gap > 180:
        years = gap / 365.25
        age = f"{years:.1f} years" if years >= 1 else f"{gap} days"
        return MismatchAlert(status="mismatch", gap_days=gap, message=(
            f"Earliest evidence ({src}) dates this image to {earliest:%d %b %Y}, about {age} before "
            f"{claimed:%d %b %Y}. It may be recycled from an earlier event.")), earliest
    return MismatchAlert(status="consistent", gap_days=max(gap, 0), message=(
        f"Earliest evidence ({src}) is {earliest:%d %b %Y}, consistent with the claimed date.")), earliest
