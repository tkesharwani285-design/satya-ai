"""Voice-note analysis: Whisper transcription + spectral heuristics for synthetic speech."""
import asyncio
import io
import logging
import os
import tempfile
import wave
from dataclasses import dataclass
from pathlib import Path

import httpx
import numpy as np

from config import get_settings
from schemas import AudioSignal

log = logging.getLogger("satya.audio")
settings = get_settings()
SR, MAX_SECONDS = 22050, 90
N_FFT, HOP = 1024, 512


@dataclass
class Transcript:
    status: str  # ok | unavailable | failed
    text: str | None = None
    language: str | None = None
    english: str | None = None  # English translation, used for fact-checking non-English speech
    provider: str | None = None


SARVAM_URL = "https://api.sarvam.ai/speech-to-text"
SARVAM_CHUNK_SECONDS = 28  # Sarvam's sync REST endpoint accepts at most 30 s per request


def _wav_bytes(x: np.ndarray, sr: int) -> bytes:
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes((np.clip(x, -1, 1) * 32767).astype(np.int16).tobytes())
    return buf.getvalue()


async def _sarvam_call(client: httpx.AsyncClient, chunk: np.ndarray, mode: str) -> tuple[str, str | None]:
    r = await client.post(SARVAM_URL, headers={"api-subscription-key": settings.sarvam_api_key},
                          data={"model": settings.sarvam_stt_model, "mode": mode},
                          files={"file": ("chunk.wav", _wav_bytes(chunk, 16000), "audio/wav")}, timeout=60)
    r.raise_for_status()
    j = r.json()
    return (j.get("transcript") or "").strip(), j.get("language_code")


async def _transcribe_sarvam(client: httpx.AsyncClient, data: bytes, suffix: str) -> Transcript:
    x = await decode(data, suffix, 16000)
    size = SARVAM_CHUNK_SECONDS * 16000
    chunks = [x[i:i + size] for i in range(0, len(x), size) if len(x[i:i + size]) >= 8000]
    try:
        first = await asyncio.gather(*(_sarvam_call(client, c, "transcribe") for c in chunks))
    except (httpx.HTTPError, ValueError) as e:
        log.warning("Sarvam transcription failed: %s", e)
        return Transcript("failed", provider="sarvam")
    text = " ".join(t for t, _ in first if t).strip()
    lang = next((lang for _, lang in first if lang), None)
    english = None
    if text and lang and not lang.lower().startswith("en"):
        try:
            tr = await asyncio.gather(*(_sarvam_call(client, c, "translate") for c in chunks))
            english = " ".join(t for t, _ in tr if t).strip() or None
        except (httpx.HTTPError, ValueError) as e:
            log.warning("Sarvam translation failed: %s", e)
    return Transcript("ok", text, lang, english, "sarvam")


async def _transcribe_openai(client: httpx.AsyncClient, data: bytes, filename: str) -> Transcript:
    try:
        r = await client.post("https://api.openai.com/v1/audio/transcriptions",
                              headers={"Authorization": f"Bearer {settings.openai_api_key}"},
                              data={"model": settings.whisper_model},
                              files={"file": (filename, data, "application/octet-stream")}, timeout=90)
        r.raise_for_status()
        return Transcript("ok", (r.json().get("text") or "").strip(), provider="openai")
    except (httpx.HTTPError, ValueError) as e:
        log.warning("Whisper transcription failed: %s", e)
        return Transcript("failed", provider="openai")


async def transcribe(client: httpx.AsyncClient, data: bytes, filename: str) -> Transcript:
    provider = settings.transcription_provider.lower()
    if provider in ("auto", "sarvam") and settings.sarvam_api_key:
        return await _transcribe_sarvam(client, data, Path(filename).suffix.lower() or ".wav")
    if provider in ("auto", "openai") and settings.openai_api_key:
        return await _transcribe_openai(client, data, filename)
    return Transcript("unavailable")


async def decode(data: bytes, suffix: str, sr: int = SR) -> np.ndarray:
    """Decode any ffmpeg-supported audio to mono float32 (temp file: m4a needs seeking)."""
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as f:
        f.write(data)
        path = f.name
    try:
        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-v", "error", "-nostdin", "-i", path, "-t", str(MAX_SECONDS),
            "-f", "f32le", "-ac", "1", "-ar", str(sr), "pipe:1",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
        out, _ = await proc.communicate()
    except FileNotFoundError:
        raise RuntimeError("ffmpeg is not installed on the server.")
    finally:
        os.unlink(path)
    if proc.returncode != 0 or not out:
        raise ValueError("Could not decode the audio file.")
    return np.frombuffer(out, dtype=np.float32).copy()


def _clip(v: float) -> float:
    return float(min(1.0, max(0.0, v)))


def analyze_samples(x: np.ndarray) -> tuple[int, list[AudioSignal]]:
    if len(x) < SR * 2:
        raise ValueError("Audio is too short to analyze (need at least 2 seconds).")
    x = x / (np.max(np.abs(x)) + 1e-9)
    win = np.hanning(N_FFT).astype(np.float32)
    starts = np.arange(0, len(x) - N_FFT, HOP)
    rms, f0s, peaks = [], [], []
    spec = np.zeros(N_FFT + 1)
    for i in range(0, len(starts), 256):
        fr = x[starts[i:i + 256][:, None] + np.arange(N_FFT)[None, :]]
        rms.append(np.sqrt((fr ** 2).mean(1)))
        P = np.abs(np.fft.rfft(fr * win, 2 * N_FFT, axis=1)) ** 2
        spec += P.sum(0)
        ac = np.fft.irfft(P, 2 * N_FFT, axis=1)[:, :400]
        lag = ac[:, 55:341]  # ~65-400 Hz
        f0s.append(SR / (lag.argmax(1) + 55))
        peaks.append(lag.max(1) / (ac[:, 0] + 1e-9))
    db = 20 * np.log10(np.concatenate(rms) + 1e-9)
    f0, peak = np.concatenate(f0s), np.concatenate(peaks)
    sec = len(x) / SR
    signals: list[AudioSignal] = []

    # 1) noise floor: synthetic audio often has near-digital silence between phrases
    floor = float(np.percentile(db, 5))
    c_floor = _clip((-floor - 55) / 25)
    signals.append(AudioSignal(name="noise_floor_db", value=f"{floor:.1f}", flagged=c_floor > 0.5,
                               note="Near-digital silence between phrases is typical of generated audio."))

    # 2) pitch variation (robust semitone spread over voiced frames)
    voiced = (peak > 0.45) & (db > db.max() - 35)
    if voiced.sum() >= 30:
        st = 12 * np.log2(f0[voiced] / np.median(f0[voiced]))
        mad = float(np.median(np.abs(st - np.median(st))) * 1.4826)
        c_pitch = _clip((2.5 - mad) / 2.0)
        signals.append(AudioSignal(name="pitch_variation_semitones", value=f"{mad:.2f}", flagged=mad < 1.2,
                                   note="Very flat intonation is a common TTS/voice-clone trait."))
    else:
        c_pitch = 0.3
        signals.append(AudioSignal(name="pitch_variation_semitones", value="n/a", flagged=False,
                                   note="Too little voiced speech to measure pitch."))

    # 3) pause structure
    silent = db < (np.percentile(db, 95) - 35)
    runs, cur = [], 0
    for s in silent:
        if s:
            cur += 1
        elif cur:
            runs.append(cur)
            cur = 0
    pauses = [r * HOP / SR for r in runs if r * HOP / SR >= 0.15]
    if sec > 12 and not pauses:
        c_pause, val = 0.8, "no pauses"
    elif len(pauses) >= 4:
        cv = float(np.std(pauses) / (np.mean(pauses) + 1e-9))
        c_pause, val = _clip((0.45 - cv) / 0.35), f"{len(pauses)} pauses, CV {cv:.2f}"
    else:
        c_pause, val = 0.3, f"{len(pauses)} pauses"
    signals.append(AudioSignal(name="pause_regularity", value=val, flagged=c_pause > 0.6,
                               note="Natural speech has irregular pauses and breaths; TTS is often uniform."))

    # 4) high-frequency energy cutoff
    freqs = np.fft.rfftfreq(2 * N_FFT, 1 / SR)
    hf = float(spec[freqs >= 8000].sum() / (spec.sum() + 1e-12))
    c_hf = _clip((-np.log10(hf + 1e-12) - 4) / 2)
    signals.append(AudioSignal(name="energy_above_8khz", value=f"{hf:.2e}", flagged=c_hf > 0.5,
                               note="Abrupt band-limiting can indicate a neural vocoder (also common in phone codecs)."))

    conf = round(100 * (0.30 * c_pitch + 0.25 * c_floor + 0.25 * c_pause + 0.20 * c_hf))
    return conf, signals


def status_for(conf: int) -> str:
    return "natural_variation" if conf < 35 else "inconclusive" if conf < 65 else "synthetic_artifacts"


async def analyze_file(data: bytes, suffix: str) -> tuple[int, list[AudioSignal], float]:
    x = await decode(data, suffix)
    conf, signals = await asyncio.to_thread(analyze_samples, x)
    return conf, signals, round(len(x) / SR, 1)
