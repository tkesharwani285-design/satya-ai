"""Synthetic Amplification Index from account-age, duplication, velocity and sentiment patterns."""
import hashlib
import random
import re
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from statistics import mean, pstdev

import httpx

from config import get_settings
from schemas import TimelinePoint
from services.nlp_processor import quick_emotion
from services.scraper import parse_date

settings = get_settings()


class ProviderError(Exception):
    def __init__(self, status: int, message: str):
        super().__init__(message)
        self.status, self.message = status, message


@dataclass
class Post:
    author_id: str
    text: str
    ts: datetime
    account_created: datetime
    followers: int
    following: int


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


async def fetch_posts(client: httpx.AsyncClient, query: str) -> list[Post] | None:
    """Return recent public posts, or None when no social-data provider is configured."""
    if not settings.x_bearer_token:
        return None
    r = await client.get("https://api.twitter.com/2/tweets/search/recent",
                         headers={"Authorization": f"Bearer {settings.x_bearer_token}"},
                         params={"query": query, "max_results": 100, "tweet.fields": "created_at,author_id",
                                 "expansions": "author_id", "user.fields": "created_at,public_metrics"})
    if r.status_code == 429:
        raise ProviderError(429, "Social data provider rate limit reached. Try again later.")
    if r.status_code >= 400:
        raise ProviderError(502, f"Social data provider returned HTTP {r.status_code}.")
    j = r.json()
    users = {u["id"]: u for u in j.get("includes", {}).get("users", [])}
    posts = []
    for t in j.get("data", []):
        u = users.get(t.get("author_id"))
        ts, created = parse_date(t.get("created_at")), parse_date(u.get("created_at")) if u else None
        if not (u and ts and created):
            continue
        m = u.get("public_metrics", {})
        posts.append(Post(u["id"], t["text"], ts, created, m.get("followers_count", 0), m.get("following_count", 0)))
    return posts


def simulate_posts(query: str) -> list[Post]:
    """Deterministic demo data (flagged as simulated in the response)."""
    rng = random.Random(int(hashlib.sha256(query.encode()).hexdigest(), 16))
    level, now = rng.uniform(0.1, 0.9), _now()
    bot_tpl = ["Share this before it is deleted! {q}", "BREAKING: {q} they are hiding the truth!"]
    human_tpl = ["{q} what do you think?", "Can't believe this about {q}", "Interesting thread on {q}"]
    posts = []
    for i in range(120):
        bot = rng.random() < level
        minutes = rng.uniform(40, 55) if bot and rng.random() < 0.7 else rng.uniform(0, 180)
        text = (rng.choice(bot_tpl).format(q=query) if bot
                else f"{rng.choice(human_tpl).format(q=query)} #{rng.randint(1, 9999)}")
        posts.append(Post(f"sim{i}", text, now - timedelta(minutes=minutes),
                          now - timedelta(days=rng.uniform(1, 25) if bot else rng.uniform(200, 3000)),
                          rng.randint(0, 15) if bot else rng.randint(50, 3000),
                          rng.randint(200, 2000) if bot else rng.randint(50, 800)))
    return posts


def score(posts: list[Post]) -> dict:
    n = len(posts)
    new_ratio = sum((p.ts - p.account_created).days < 30 for p in posts) / n
    norm = [" ".join(re.sub(r"https?://\S+|@\w+|[^a-z0-9# ]", " ", p.text.lower()).split()[:12]) for p in posts]
    dup = sum(c for c in Counter(norm).values() if c >= 3) / n
    lowcred = sum(p.followers < 20 and p.following > 5 * max(p.followers, 1) for p in posts) / n

    buckets = Counter(p.ts.replace(minute=p.ts.minute // 5 * 5, second=0, microsecond=0) for p in posts)
    vals = list(buckets.values())
    velocity = min(100, round((max(vals) / mean(vals) - 1) * 25)) if len(vals) > 1 else 0

    accounts = {p.author_id: p.account_created for p in posts}
    weeks = Counter(d.toordinal() // 7 for d in accounts.values())
    spikes = sum(c >= max(3, 0.2 * len(accounts)) for c in weeks.values())

    emo = [quick_emotion(p.text) for p in posts]
    coord = round(min(100, mean(emo)) * (1 - min(pstdev(emo) / 50, 1)))

    total = round(0.30 * new_ratio * 100 + 0.25 * dup * 100 + 0.20 * velocity + 0.15 * lowcred * 100 + 0.10 * coord)
    timeline = [TimelinePoint(t=t.isoformat() + "Z", count=c) for t, c in sorted(buckets.items())][-48:]
    return {"score": max(0, min(100, total)), "spikes": spikes, "velocity": velocity,
            "new": round(new_ratio * 100), "dup": round(dup * 100), "coord": coord, "timeline": timeline}
