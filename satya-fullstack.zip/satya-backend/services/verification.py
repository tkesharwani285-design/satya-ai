"""Shared claim-verification pipeline used by the text, url and audio routers."""
import asyncio

import httpx

from schemas import (ClaimGraph, ClaimResult, GraphEdge, GraphNode, SourceReceipt,
                     TextVerificationResponse, verdict_for)
from services import factcheck_api as fc
from services import nlp_processor as nlp

_ORDER = ["false", "misleading", "true", "covered", "not_found", "unavailable"]


def _merge(results: list[fc.FactCheckResult]) -> list[SourceReceipt]:
    merged: dict[str, SourceReceipt] = {}
    for r in results:
        for rc in r.receipts:
            cur = merged.get(rc.source)
            if cur is None or _ORDER.index(rc.status) < _ORDER.index(cur.status):
                merged[rc.source] = rc
    return list(merged.values())


def _graph(claims: list[tuple[str, list[str]]], receipts: list[SourceReceipt]) -> ClaimGraph:
    nodes, edges, seen = [], [], set()

    def add(node: GraphNode):
        if node.id not in seen:
            seen.add(node.id)
            nodes.append(node)

    for r in receipts:
        if r.status not in ("not_found", "unavailable"):
            add(GraphNode(id=f"s:{r.source}", label=r.source, type="source", status=r.status))
    for i, (text, ents) in enumerate(claims):
        cid = f"c{i}"
        add(GraphNode(id=cid, label=text[:90], type="claim"))
        for e in ents:
            add(GraphNode(id=f"e:{e}", label=e, type="entity"))
            edges.append(GraphEdge(source=cid, target=f"e:{e}", relation="mentions"))
        for r in receipts:
            if r.status not in ("not_found", "unavailable"):
                edges.append(GraphEdge(source=cid, target=f"s:{r.source}", relation="checked_by"))
    return ClaimGraph(nodes=nodes, edges=edges)


async def verify_claim_text(client: httpx.AsyncClient, text: str,
                            priority_claims: list[str] | None = None) -> TextVerificationResponse:
    ling = nlp.analyze(text)
    claims = [(c[:280], nlp.entities(c)) for c in (priority_claims or []) if c.strip()]
    claims += [c for c in nlp.extract_claims(text) if c[0] not in {x[0] for x in claims}]
    claims = claims[:3]

    results = await asyncio.gather(*(fc.lookup(client, c) for c, _ in claims))
    receipts = _merge(results)
    truths = [r.consensus for r in results if r.consensus is not None]
    consensus = sum(truths) / len(truths) if truths else None
    coverage = ("unavailable" if all(r.coverage == "unavailable" for r in results)
                else "found" if any(r.coverage == "found" for r in results) else "none")

    ling_risk = 100 - ling.neutrality
    risk = (round(0.8 * (1 - consensus) * 100 + 0.2 * ling_risk) if consensus is not None
            else round(25 + 0.5 * ling_risk))
    risk = max(0, min(100, risk))
    trust = 100 - risk

    if consensus is not None:
        s1 = ("Independent fact-checkers rate related claims as mostly false or misleading." if consensus < 0.35
              else "Fact-check coverage of related claims is mixed." if consensus < 0.65
              else "Related claims are largely confirmed by fact-checkers.")
    elif coverage == "unavailable":
        s1 = "Fact-check lookups are not configured, so this score reflects language analysis only."
    else:
        s1 = "No existing fact-check was found for this claim, so it remains unverified."
    s2 = f"The wording scores {ling.sensationalism}/100 for sensationalism with {ling.neutrality}% neutrality"
    if ling.highlighted_phrases:
        s2 += f" (flagged: {', '.join(sorted({h.phrase.lower() for h in ling.highlighted_phrases})[:4])})"

    return TextVerificationResponse(
        trust_score=trust, risk_score=risk, verdict=verdict_for(trust), summary=f"{s1} {s2}.",
        fact_check_coverage=coverage, linguistic=ling,
        claims=[ClaimResult(claim=c, entities=e, consensus_truth=None if r.consensus is None else round(r.consensus, 2),
                            matches=r.matches) for (c, e), r in zip(claims, results)],
        claim_graph=_graph(claims, receipts), source_receipts=receipts)
