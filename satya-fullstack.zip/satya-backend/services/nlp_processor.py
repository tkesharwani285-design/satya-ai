"""Heuristic linguistic scoring: sensationalism, clickbait, emotional bias, neutrality.

Lexicon/rule based, so it runs offline and is fully explainable. It flags *style*
associated with misinformation; it cannot judge whether a claim is factually true.
"""
import re

from schemas import HeatmapSegment, LinguisticAnalysis, PhraseHit


def _rx(parts: list[str]) -> re.Pattern:
    return re.compile(r"\b(?:" + "|".join(parts) + r")\b", re.I)


SENSATIONAL = _rx([
    r"breaking", r"shocking", r"unbelievable", r"exposed", r"bombshell", r"explosive",
    r"horrifying", r"outrageous", r"scandal", r"miracle", r"banned", r"cover[- ]?up",
    r"leaked", r"massive", r"devastating", r"insane", r"jaw[- ]dropping", r"stunning",
    r"must[- ]see", r"mind[- ]blowing", r"exclusive",
])
CLICKBAIT = _rx([
    r"you won'?t believe", r"what happens next", r"this is why", r"here'?s why",
    r"doctors hate", r"\d+ (?:things|reasons|ways|facts)", r"will (?:shock|blow) you",
    r"gone wrong", r"goes viral", r"the truth about", r"nobody (?:is )?talking about",
    r"click (?:here|now)",
])
EMOTIONAL = _rx([
    r"terrifying", r"disgusting", r"evil", r"traitors?", r"furious", r"panic",
    r"destroy(?:ed|ing)?", r"slaughter(?:ed)?", r"drowning", r"trapped", r"tragedy",
    r"betray(?:ed|al)?", r"hate", r"enraged", r"nightmare", r"catastrophe",
    r"horrific", r"heartbreaking", r"outrage",
])
URGENCY = _rx([
    r"share (?:this )?before", r"forward (?:this )?to (?:everyone|all)", r"spread the word",
    r"before (?:it|they) (?:gets?|delete)", r"share (?:this )?(?:now|widely)", r"wake up",
    r"they (?:don'?t|do not) want you to know", r"(?:media|government|they)(?: is| are)? (?:hiding|lying)",
    r"hiding the truth", r"mainstream media won'?t", r"forwarded as received", r"urgent",
])
ATTRIBUTION = _rx([
    r"according to", r"said", r"stated", r"reported", r"spokes(?:person|man|woman)",
    r"officials?", r"data shows?", r"study", r"statement", r"announced", r"confirmed",
    r"percent", r"report",
])
CATEGORIES = (("sensational", SENSATIONAL), ("clickbait", CLICKBAIT),
              ("emotional", EMOTIONAL), ("urgency", URGENCY))

_SENT = re.compile(r"[^.!?\n]+[.!?]*")
_ENT = re.compile(r"\b(?:[A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+)+|[A-Z][a-z]{2,}|[A-Z]{2,5})\b")
_NUM = re.compile(r"\b\d[\d,.]*(?:\s?(?:%|percent|crore|lakh|million|billion|people|deaths?|years?))?", re.I)
_FACT_VERB = re.compile(
    r"\b(?:said|says|announced|killed|died|banned|approved|launched|arrested|declared|"
    r"found|confirmed|ordered|signed|cut|raised|will|has|have)\b", re.I)
_STOP = {"The", "This", "That", "These", "Those", "Share", "Forward", "Please", "Today", "Now", "Here"}


def _caps_ratio(s: str) -> float:
    letters = [c for c in s if c.isalpha()]
    return sum(c.isupper() for c in letters) / len(letters) if len(letters) >= 8 else 0.0


def find_phrases(text: str) -> list[PhraseHit]:
    hits = [PhraseHit(phrase=m.group(0), category=cat, start=m.start(), end=m.end())
            for cat, rx in CATEGORIES for m in rx.finditer(text)]
    return sorted(hits, key=lambda h: h.start)


def analyze(text: str) -> LinguisticAnalysis:
    text = text.strip()
    hits = find_phrases(text)
    n = {c: sum(h.category == c for h in hits) for c, _ in CATEGORIES}
    excl, caps = text.count("!"), _caps_ratio(text)
    attrib = len(ATTRIBUTION.findall(text))

    sens = min(100, 20 * n["sensational"] + 18 * n["urgency"] + 5 * min(excl, 5) + int(caps * 120))
    click = min(100, 30 * n["clickbait"] + 6 * min(excl, 3))
    emo = min(100, 18 * n["emotional"] + 7 * min(excl, 4) + 6 * n["sensational"] + int(caps * 40))
    risk = round(0.5 * sens + 0.2 * click + 0.3 * emo)
    neutrality = max(0, min(100, 100 - risk + min(20, 6 * attrib)))

    segments: list[HeatmapSegment] = []
    for m in _SENT.finditer(text):
        raw = m.group(0)
        s = raw.strip()
        if not s:
            continue
        start = m.start() + (len(raw) - len(raw.lstrip()))
        end = start + len(s)
        inside = [h for h in hits if h.start >= start and h.end <= end]
        c, e = _caps_ratio(s), s.count("!")
        labels = {h.category for h in inside}
        if c > 0.6:
            labels.add("shouting")
        if e >= 2:
            labels.add("exclamation")
        score = min(100, 28 * len(inside) + 7 * min(e, 4) + int(c * 50))
        segments.append(HeatmapSegment(text=s[:300], start=start, end=end, score=score, labels=sorted(labels)))
        if len(segments) >= 60:
            break

    return LinguisticAnalysis(sensationalism=sens, clickbait=click, emotional_bias=emo,
                              neutrality=neutrality, heatmap=segments, highlighted_phrases=hits[:80])


def entities(sentence: str) -> list[str]:
    out: list[str] = []
    for e in _ENT.finditer(sentence):
        w = e.group(0)
        if e.start() == 0 and " " not in w:
            continue
        if w in _STOP or SENSATIONAL.fullmatch(w) or URGENCY.fullmatch(w) or w in out:
            continue
        out.append(w)
    return out[:6]


def extract_claims(text: str, limit: int = 3) -> list[tuple[str, list[str]]]:
    """Pick the most checkable sentences (numbers, named entities, factual verbs)."""
    cands = []
    for m in _SENT.finditer(text):
        s = m.group(0).strip()
        if len(s.split()) < 5:
            continue
        ents = entities(s)
        score = (2 * len(_NUM.findall(s)) + len(ents) + (2 if _FACT_VERB.search(s) else 0)
                 - (4 if URGENCY.search(s) else 0))
        cands.append((score, m.start(), s[:280], ents))
    if not cands:
        return [(text[:280], entities(text[:280]))]
    top = sorted(cands, key=lambda c: (-c[0], c[1]))[:limit]
    return [(c[2], c[3]) for c in sorted(top, key=lambda c: c[1])]


def quick_emotion(text: str) -> int:
    n = len(EMOTIONAL.findall(text)) + len(SENSATIONAL.findall(text))
    return min(100, 25 * n + 8 * min(text.count("!"), 4) + int(_caps_ratio(text) * 40))
