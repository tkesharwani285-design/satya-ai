# Satya.ai: frontend + backend, run locally

```
satya-backend/    FastAPI, port 8000
satya-frontend/   Vite + React + Tailwind, port 5173
```

## 1. Backend (terminal 1)
```bash
cd satya-backend
python3 -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env     # skip if .env already exists; add your API keys (SARVAM_API_KEY, etc.)
uvicorn main:app --reload --port 8000
```
Check: http://localhost:8000/api/v1/health and http://localhost:8000/docs

## 2. Frontend (terminal 2)
```bash
cd satya-frontend
npm install
npm run dev
```
Open http://localhost:5173. The header badge turns green and shows the backend latency when the API is reachable.

## Notes
- Every API key is optional. Missing keys disable that check and the dashboard says so (see "API Status" at the bottom of the page).
- Bot Swarm needs `X_BEARER_TOKEN`. For local demos set `ALLOW_SIMULATED=true` in `satya-backend/.env` (results are labelled simulated).
- Tests: `cd satya-backend && pip install pytest && pytest`
